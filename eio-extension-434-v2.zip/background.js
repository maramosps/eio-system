/*
═══════════════════════════════════════════════════════════
  E.I.O - BACKGROUND SCRIPT (Service Worker)
  Motor de automação ultra-estável - VERSÃO 4.3.4
  COM DELAYS SEGUROS (120-180s) e Múltiplas Ações
═══════════════════════════════════════════════════════════
*/

console.log('E.I.O Extension v4.3.4 starting...');

// ═══════════════════════════════════════════════════════════
// API CONFIG - Sincronização com Dashboard
// ═══════════════════════════════════════════════════════════
const API_BASE_URL = 'https://eio-api.vercel.app/api';

// Função para sincronizar ação com o Dashboard (via API)
async function syncActionToCloud(actionType, targetUsername, success, details = {}) {
    try {
        const storage = await chrome.storage.local.get(['userId', 'accountHandle', 'authToken']);
        const userId = storage.userId;
        const accountHandle = storage.accountHandle;

        if (!userId) {
            console.log('[E.I.O Sync] userId não encontrado, ação não sincronizada');
            return;
        }

        console.log('[E.I.O Sync] Sincronizando ação:', actionType, '@' + targetUsername);

        const response = await fetch(`${API_BASE_URL}/v1/sync-action`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': storage.authToken ? `Bearer ${storage.authToken}` : ''
            },
            body: JSON.stringify({
                userId,
                accountHandle: accountHandle || '@unknown',
                actionType,
                targetUsername,
                success,
                details
            })
        });

        if (response.ok) {
            console.log(`[E.I.O Sync] ✅ Ação ${actionType} sincronizada com sucesso`);
        } else {
            console.log(`[E.I.O Sync] ⚠️ Falha ao sincronizar: ${response.status}`);
        }
    } catch (error) {
        console.log('[E.I.O Sync] Erro ao sincronizar:', error.message);
    }
}

let extensionState = {
    isRunning: false,
    isPausedForSafety: false,
    currentActions: [], // LISTA de ações (array)
    currentOptions: {},
    stats: {
        followsToday: 0, likesToday: 0, commentsToday: 0,
        storiesLikedToday: 0, unfollowsToday: 0, dmsToday: 0,
        totalActionsToday: 0, sessionStartTime: null
    },
    limits: {
        maxFollowsPerDay: 200, maxUnfollowsPerDay: 500,
        maxLikesPerDay: 300, maxTotalActionsPerDay: 1000,
        actionsBeforePause: 25, pauseDurationMinutes: 60
    },
    actionsInCurrentBatch: 0,
    queue: [],
    activeTabId: null
};


// ═══════════════════════════════════════════════════════════
// DELAYS SEGUROS (120s - 180s entre perfis)
// ═══════════════════════════════════════════════════════════
const DELAY_CONFIG = {
    // Delay entre AÇÕES no MESMO perfil (seguir -> curtir -> stories)
    BETWEEN_ACTIONS_SAME_PROFILE: 30000, // 30 segundos

    // Delay entre PERFIS DIFERENTES (120s a 180s)
    MIN_BETWEEN_PROFILES: 120000, // 2 minutos
    MAX_BETWEEN_PROFILES: 180000 // 3 minutos
};

let isProcessing = false;
let isWaitingDelay = false;
let processingTimeout = null;

// ═══════════════════════════════════════════════════════════
// PERSISTENCE
// ═══════════════════════════════════════════════════════════

async function saveState() {
    try {
        await chrome.storage.local.set({
            extensionState: {
                ...extensionState,
                isRunning: extensionState.isRunning && extensionState.queue.length > 0
            }
        });
    } catch (e) {
        console.error('Save state error:', e);
    }
}

async function loadState() {
    try {
        const result = await chrome.storage.local.get(['extensionState']);
        if (result.extensionState) {
            extensionState = { ...extensionState, ...result.extensionState };
            console.log('[E.I.O] Estado carregado. Fila:', extensionState.queue.length);
        }
    } catch (e) {
        console.error('Load state error:', e);
    }
}

// ═══════════════════════════════════════════════════════════
// KEEP ALIVE
// ═══════════════════════════════════════════════════════════

chrome.alarms.create('keepAlive', { periodInMinutes: 0.4 });

chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === 'keepAlive') {
        console.log('[E.I.O KeepAlive] Check - Running:', extensionState.isRunning, 'Queue:', extensionState.queue.length, 'Processing:', isProcessing, 'WaitingDelay:', isWaitingDelay);
        // CRÍTICO: NÃO reiniciar se estiver aguardando o delay de segurança!
        if (extensionState.isRunning && !isProcessing && !isWaitingDelay && extensionState.queue.length > 0) {
            console.log('[E.I.O KeepAlive] Detectou travamento real! Reiniciando motor...');
            processQueue();
        }
    }
});


// ═══════════════════════════════════════════════════════════
// MESSAGE LISTENER
// ═══════════════════════════════════════════════════════════

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    const action = message.action || message.type;
    console.log('[E.I.O] Mensagem recebida:', action, message);

    switch (action) {
        case 'setQueue':
            extensionState.queue = message.queue || [];
            // Salvar tamanho inicial da fila para o contador de progresso
            totalQueueSize = extensionState.queue.length;
            processedCount = 0;
            console.log('[E.I.O] Fila configurada via setQueue:', extensionState.queue.length);
            saveState();
            sendResponse({ success: true, count: extensionState.queue.length });
            break;

        case 'startAutomation':
            // Passar mensagem completa para handleStartAutomation
            handleStartAutomation(message, sendResponse);
            return true;

        case 'pauseAutomation':
            console.log('[E.I.O] Automação pausada');
            extensionState.isRunning = false;
            if (processingTimeout) clearTimeout(processingTimeout);
            saveState();
            notifyPopup('automationPaused', {});
            sendResponse({ success: true });
            break;

        case 'stopAutomation':
            console.log('[E.I.O] Automação parada');
            extensionState.isRunning = false;
            extensionState.queue = [];
            isProcessing = false;
            isWaitingDelay = false;
            if (processingTimeout) clearTimeout(processingTimeout);
            saveState();
            notifyPopup('automationStopped', {});
            sendResponse({ success: true });
            break;

        case 'getStatus':
            sendResponse({
                isRunning: extensionState.isRunning,
                queueLength: extensionState.queue.length,
                stats: extensionState.stats,
                isProcessing: isProcessing
            });
            break;

        case 'console_log':
            // Recebe logs do content script
            console.log(`[ContentScript ${message.level}] ${message.message}`);
            break;
    }
    return true;
});

async function handleStartAutomation(message, sendResponse) {
    try {
        console.log('[E.I.O] Iniciando automação...');

        // Extrair dados do payload
        const data = (message && message.data) ? message.data : {};
        const targets = data.targets || [];     // Array de strings (usernames)
        const actions = data.actions || [];     // Array de strings (follow, like...)
        const options = data.options || {};

        if (targets.length === 0 && extensionState.queue.length === 0) {
            sendResponse({ success: false, message: 'Fila vazia. Carregue contas primeiro.' });
            return;
        }

        // Se vieram novos targets, configurar a fila com objetos complexos
        if (targets.length > 0) {
            extensionState.queue = targets.map(username => ({
                username: username,
                actions: actions, // Cada item carrega suas ações
                options: options
            }));

            extensionState.currentActions = actions;
            extensionState.currentOptions = options;

            totalQueueSize = extensionState.queue.length;
            processedCount = 0;
            console.log(`[E.I.O] Fila configurada: ${extensionState.queue.length} targets, Ações: ${actions.join('+')}`);
        } else {
            // Retomando fila existente
            console.log('[E.I.O] Retomando fila existente...');
        }

        // Buscar aba do Instagram
        const tabs = await chrome.tabs.query({ url: "*://*.instagram.com/*" });
        const instagramTab = tabs.find(t => t.active) || tabs[0];

        if (!instagramTab) {
            console.log('[E.I.O] ERRO: Nenhuma aba do Instagram encontrada');
            sendResponse({ success: false, message: 'Abra o Instagram primeiro!' });
            return;
        }

        console.log('[E.I.O] Usando aba:', instagramTab.id, 'URL:', instagramTab.url);

        if (extensionState.isRunning && (isProcessing || isWaitingDelay)) {
            sendResponse({ success: true, message: 'Já em execução' });
            return;
        }

        extensionState.activeTabId = instagramTab.id;
        extensionState.isRunning = true;
        if (!isWaitingDelay) isProcessing = false;

        saveState();

        if (!isWaitingDelay && !isProcessing) {
            processQueue();
        }

        notifyPopup('automationStarted', {});
        sendResponse({ success: true });

    } catch (e) {
        console.error('[E.I.O] Erro ao iniciar:', e);
        sendResponse({ success: false, message: e.message });
    }
}

// ═══════════════════════════════════════════════════════════
// MOTOR DE AUTOMAÇÃO
// ═══════════════════════════════════════════════════════════

let totalQueueSize = 0;
let processedCount = 0;

async function processQueue() {
    console.log('[E.I.O Motor] processQueue chamado. isProcessing:', isProcessing, 'Queue:', extensionState.queue.length);

    if (isProcessing) return;
    if (!extensionState.isRunning) return;
    if (extensionState.queue.length === 0) {
        extensionState.isRunning = false;
        notifyPopup('automationStopped', { message: 'Fila concluída!' });
        logAction('success', '✅ Fila concluída!');
        processedCount = 0;
        totalQueueSize = 0;
        saveState();
        return;
    }

    isProcessing = true;
    processedCount++;

    notifyPopup('progressUpdate', { current: processedCount, total: totalQueueSize });

    try {
        let tabId = await ensureValidTab();
        if (!tabId) throw new Error('Aba do Instagram não encontrada');

        const item = extensionState.queue.shift();

        // Determinar ações para este item (suporta fila mista ou fila simples)
        // Se item.actions não existir, usa as globais ou array vide extensionState.currentActions
        let actions = item.actions;
        if (!actions || actions.length === 0) {
            actions = extensionState.currentActions;
        }
        // Fallback antigo para currentActionType se não for array
        if (!actions || actions.length === 0) {
            actions = [extensionState.currentActionType];
        }

        const options = item.options || extensionState.currentOptions;

        console.log(`[E.I.O Motor] Processando @${item.username} - Ações: ${actions.join(', ')}`);
        logAction('info', `🎯 [${processedCount}/${totalQueueSize}] Processando @${item.username}...`);

        // Executar ações sequencialmente
        for (const actionType of actions) {
            if (!extensionState.isRunning) break;

            console.log(`[E.I.O Motor] Executando ${actionType} em @${item.username}`);

            try {
                const result = await sendMessageWithRetry(tabId, {
                    action: 'execute',
                    payload: { type: actionType, target: item.username, options }
                });

                console.log('[E.I.O Motor] Resultado:', JSON.stringify(result));

                if (result?.success || result?.meta?.success || String(result?.action).includes('followed') || String(result?.action).includes('liked')) {
                    updateStats(actionType);
                    logAction('success', `✅ ${actionType} OK (@${item.username})`);

                    let status = 'followed';
                    if (String(result?.action).includes('requested')) status = 'requested';
                    else if (actionType === 'unfollow') status = 'unfollowed';
                    else if (actionType === 'like' || actionType === 'liked') status = 'liked';

                    notifyPopup('actionCompleted', { username: item.username, action: status });
                    syncActionToCloud(actionType, item.username, true, { status, result: result?.action });
                } else {
                    logAction('warning', `⚠️ ${actionType} falhou: ${result?.error || result?.action || 'erro'}`);
                    notifyPopup('actionCompleted', { username: item.username, action: 'error' });
                    syncActionToCloud(actionType, item.username, false, { error: result?.error || result?.action });
                }
            } catch (msgError) {
                console.error(`[E.I.O Motor] Erro na mensagem:`, msgError);
                logAction('error', `❌ Erro: ${msgError.message}`);
                notifyPopup('actionCompleted', { username: item.username, action: 'error' });
                syncActionToCloud(actionType, item.username, false, { error: msgError.message });
            }

            // DELAY ENTRE AÇÕES NO MESMO PERFIL
            if (extensionState.isRunning && actions.indexOf(actionType) < actions.length - 1) {
                const delay = DELAY_CONFIG.BETWEEN_ACTIONS_SAME_PROFILE;
                logAction('info', `⏳ Aguardando ${delay / 1000}s para próxima ação...`);
                await sleep(delay);
            }
        }

        await saveState();

        // DELAY ENTRE PERFIS DIFERENTES (Randômico 120-180s)
        if (extensionState.isRunning && extensionState.queue.length > 0) {
            // Calcular delay aleatório
            const minDelay = DELAY_CONFIG.MIN_BETWEEN_PROFILES;
            const maxDelay = DELAY_CONFIG.MAX_BETWEEN_PROFILES;
            const delay = Math.floor(Math.random() * (maxDelay - minDelay + 1)) + minDelay;
            const delaySeconds = Math.round(delay / 1000);

            logAction('info', `⏱️ Próximo perfil em ${delaySeconds}s... (${extensionState.queue.length} restantes)`);

            isProcessing = false;
            isWaitingDelay = true;
            processingTimeout = setTimeout(() => {
                isWaitingDelay = false;
                processQueue();
            }, delay);
        } else {
            isProcessing = false;
            if (extensionState.queue.length === 0) {
                extensionState.isRunning = false;
                logAction('success', '✅ Fila concluída!');
                notifyPopup('automationStopped', {});
                saveState();
            }
        }

    } catch (error) {
        console.error('[E.I.O Motor] Erro:', error);
        logAction('error', `❌ Erro no motor: ${error.message}`);
        isProcessing = false;

        if (extensionState.isRunning && extensionState.queue.length > 0) {
            console.log('[E.I.O Motor] Tentando novamente em 10 segundos...');
            processingTimeout = setTimeout(() => processQueue(), 10000);
        }
    }
}

// ═══════════════════════════════════════════════════════════
// FUNÇÕES AUXILIARES
// ═══════════════════════════════════════════════════════════

async function ensureValidTab() {
    let tabId = extensionState.activeTabId;
    try {
        if (tabId) {
            const tab = await chrome.tabs.get(tabId);
            if (tab && tab.url && tab.url.includes('instagram.com')) {
                return tabId;
            }
        }
    } catch (e) { }

    const tabs = await chrome.tabs.query({ url: "*://*.instagram.com/*" });
    if (tabs.length > 0) {
        tabId = tabs[0].id;
        extensionState.activeTabId = tabId;
        return tabId;
    }
    return null;
}

async function sendMessageWithRetry(tabId, message, retries = 3) {
    for (let i = 0; i < retries; i++) {
        try {
            const result = await chrome.tabs.sendMessage(tabId, message);
            return result;
        } catch (error) {
            if (error.message.includes('context invalidated') || error.message.includes('no tab')) {
                const newTabId = await ensureValidTab();
                if (newTabId && newTabId !== tabId) {
                    tabId = newTabId;
                    continue;
                }
            }
            if (i < retries - 1) await sleep(2000);
        }
    }
    throw new Error('Não foi possível comunicar com a aba do Instagram. Atualize a página (F5).');
}

function updateStats(type) {
    extensionState.stats.totalActionsToday++;
    extensionState.actionsInCurrentBatch++;
    if (type === 'follow') extensionState.stats.followsToday++;
    if (type === 'like') extensionState.stats.likesToday++;
    if (type === 'unfollow') extensionState.stats.unfollowsToday++;
    notifyPopup('statsUpdate', { stats: extensionState.stats });
}

function logAction(level, message) {
    console.log(`[E.I.O LOG] ${message}`);
    notifyPopup('consoleMessage', { level, message, timestamp: new Date().toISOString() });
}

function notifyPopup(type, data) {
    chrome.runtime.sendMessage({ type, ...data }).catch(() => { });
}

function sleep(ms) {
    return new Promise(r => setTimeout(r, ms));
}

// ═══════════════════════════════════════════════════════════
// INICIALIZAÇÃO
// ═══════════════════════════════════════════════════════════

loadState().then(() => {
    console.log('[E.I.O v4.3.4] Background script pronto!');

    // Se havia automação em andamento, retomar
    if (extensionState.isRunning && extensionState.queue.length > 0) {
        console.log('[E.I.O] Retomando automação anterior...');
        setTimeout(() => processQueue(), 2000);
    }
});

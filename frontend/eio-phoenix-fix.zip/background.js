/*
  E.I.O System v1.0.0 (Phoenix Protocol)
  Background Service Worker
  Motor Seguro com Delays Humanizados (120s-180s)
*/

console.log('[E.I.O Phoenix] Motor Iniciado v1.0.0');

// GLOBAL STATE
let State = {
    isRunning: false,
    queue: [],
    currentBatch: 0,
    tabId: null,
    stats: { follows: 0, likes: 0, errors: 0 }
};

// DELAY CONFIG (Segurança Extrema)
const DELAYS = {
    ACTION: 30000,      // 30s entre ações no mesmo perfil (seguir -> curtir)
    PROFILE_MIN: 120000, // 2 minutos entre perfis 
    PROFILE_MAX: 180000  // 3 minutos entre perfis
};

// --- MESSAGE LISTENER ---
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    switch (msg.action) {
        case 'startAutomation':
            startEngine(msg.data, sendResponse);
            break;
        case 'pauseAutomation':
        case 'stopAutomation':
            stopEngine();
            sendResponse({ success: true });
            break;
        case 'getStatus':
            sendResponse(State);
            break;
        case 'ping':
            // Keep alive
            break;
    }
    return true; // Async response
});

// --- ENGINE CONTROLLER ---
async function startEngine(data, sendResponse) {
    if (State.isRunning) return sendResponse({ success: false, message: "Já rodando" });

    if (!data.targets || data.targets.length === 0) {
        return sendResponse({ success: false, message: "Fila vazia" });
    }

    // Setup State
    State.queue = data.targets.map(username => ({
        username,
        actions: data.actions || ['follow'], // ['follow', 'like']
        options: data.options
    }));

    // Find Instagram Tab
    const tabs = await chrome.tabs.query({ url: "*://*.instagram.com/*" });
    const activeTab = tabs.find(t => t.active) || tabs[0];

    if (!activeTab) return sendResponse({ success: false, message: "Instagram não encontrado" });

    State.tabId = activeTab.id;
    State.isRunning = true;

    console.log(`[E.I.O] Motor Rodando. Fila: ${State.queue.length}. Ações: ${data.actions}`);
    sendResponse({ success: true });

    // Start Loop
    processQueue();
}

function stopEngine() {
    State.isRunning = false;
    State.queue = [];
    notify('automationStopped');
}

// --- MAIN LOOP ---
async function processQueue() {
    if (!State.isRunning || State.queue.length === 0) {
        stopEngine();
        return;
    }

    const item = State.queue.shift(); // Get next
    notifyLog('info', `🎯 Processando @${item.username}...`);

    let successCount = 0;

    // Execute Actions Sequentially for this Profile
    for (const action of item.actions) {
        if (!State.isRunning) break;

        const result = await executeAction(action, item.username);

        if (result.success) {
            successCount++;
            notifyAction(item.username, action); // Update UI Badge
            State.stats[action + 's']++; // tracks likes, follows...
        } else {
            notifyAction(item.username, 'error');
            notifyLog('error', `Falha ao ${action} @${item.username}`);
        }

        // Delay between actions (Follow -> Wait 30s -> Like)
        if (item.actions.indexOf(action) < item.actions.length - 1) {
            await sleep(DELAYS.ACTION);
        }
    }

    // Delay between Profiles (120-180s)
    if (State.isRunning && State.queue.length > 0) {
        const delay = getRandomDelay(DELAYS.PROFILE_MIN, DELAYS.PROFILE_MAX);
        notifyLog('warning', `⏳ Aguardando ${Math.round(delay / 1000)}s para próximo perfil...`);

        // Wait and Recursive Call
        setTimeout(processQueue, delay);
    } else {
        stopEngine();
    }
}

// --- ACTION EXECUTOR (Talking to Content Script) ---
async function executeAction(action, username) {
    try {
        console.log(`[E.I.O] Executing ${action} on ${username}`);
        // Aqui enviamos para o content.js que sabe navegar na API privada
        // Precisamos garantir que o content.js tenha handler para 'execute_action'
        const response = await chrome.tabs.sendMessage(State.tabId, {
            action: 'execute_action', // Content script V4 logic
            type: action,
            username: username
        });
        return response || { success: false };
    } catch (e) {
        console.error("Exec Error:", e);
        // Tentar recuperar aba se perdeu
        return { success: false };
    }
}

// --- HELPERS ---
function notify(type, data = {}) {
    chrome.runtime.sendMessage({ type, ...data }).catch(() => { });
}
function notifyLog(level, msg) {
    notify('consoleMessage', { level, message: msg });
}
function notifyAction(username, action) {
    notify('actionCompleted', { username, action });
}
function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }
function getRandomDelay(min, max) { return Math.floor(Math.random() * (max - min) + min); }

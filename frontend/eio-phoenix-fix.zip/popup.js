// E.I.O System v1.1.0 - Frontend Logic
// Phoenix Protocol + Login Restore + Rocket Icon

const AppState = {
    accounts: [],
    selectedActions: new Set(['follow']), // Default
    isRunning: false,
    stats: { today: 0 }
};

document.addEventListener('DOMContentLoaded', () => {
    // 1. Check Login First (BLOQUEANTE)
    checkLoginStatus().then(isLogged => {
        if (isLogged) {
            console.log('Login verificado. Iniciando...');
            initApp();
        } else {
            console.log('Usuário não logado. Bloqueando...');
            showLoginScreen();
        }
    });
});

function initApp() {
    initTabs();
    initActionSelectors();
    initDropdowns();
    initControls();
    initKeepAlive();

    // Check connection with background
    chrome.runtime.sendMessage({ action: 'getStatus' }, (response) => {
        if (response) {
            updateUI(response);
            if (response.queueLength > 0) {
                chrome.runtime.sendMessage({ action: 'getQueue' });
            }
        }
    });

    detectInstagramProfile();
}

// --- LOGIN LOGIC ---
async function checkLoginStatus() {
    return new Promise(resolve => {
        chrome.cookies.get({ url: 'https://eio-system.vercel.app', name: 'auth_token' }, (cookie) => {
            if (cookie) return resolve(true);

            // Backup check
            chrome.storage.local.get(['authToken'], (res) => {
                resolve(!!res.authToken);
            });
        });
    });
}

function showLoginScreen() {
    document.body.innerHTML = `
        <div style="display:flex; flex-direction:column; justify-content:center; align-items:center; height:100vh; text-align:center; padding:20px; background:#121218; color:#fff; font-family:sans-serif;">
            <div style="font-size:50px; margin-bottom:20px;">🚀</div>
            <h2 style="margin:0 0 10px 0;">Login Necessário</h2>
            <p style="color:#aaa; margin-bottom:30px; font-size:14px;">Acesse seu painel para ativar a extensão.</p>
            <button id="btnLoginAction" 
                style="background:#6246EA; color:white; border:none; padding:12px 24px; border-radius:8px; font-weight:bold; cursor:pointer; width:100%;">
                Entrar no Sistema
            </button>
            <button id="btnReloadAction" 
                style="background:transparent; border:1px solid #333; color:#aaa; margin-top:15px; padding:8px 16px; border-radius:8px; cursor:pointer; font-size:12px;">
                🔄 Verificar novamente
            </button>
        </div>
    `;

    // CSP Secure Event Listeners
    document.getElementById('btnLoginAction').addEventListener('click', () => {
        window.open('https://eio-system.vercel.app/login', '_blank');
    });

    document.getElementById('btnReloadAction').addEventListener('click', () => {
        location.reload();
    });
}

// --- TABS & NAVIGATION ---
function initTabs() {
    document.querySelectorAll('.nav-tab').forEach(btn => {
        btn.addEventListener('click', () => {
            document.querySelectorAll('.nav-tab, .tab-content').forEach(el => el.classList.remove('active'));
            btn.classList.add('active');
            document.getElementById(`tab-${btn.dataset.tab}`).classList.add('active');
        });
    });
}

// --- ACTION SELECTORS (Follow/Like/Comment...) ---
function initActionSelectors() {
    document.querySelectorAll('.action-btn').forEach(btn => {
        // Set initial state
        if (AppState.selectedActions.has(btn.dataset.action)) {
            btn.classList.add('active');
        }

        btn.addEventListener('click', () => {
            const action = btn.dataset.action;
            btn.classList.toggle('active');

            if (btn.classList.contains('active')) {
                AppState.selectedActions.add(action);
                // Unfollow mutual exclusivity logic
                if (action === 'unfollow') {
                    AppState.selectedActions.delete('follow');
                    document.querySelector('[data-action="follow"]')?.classList.remove('active');
                } else if (action === 'follow') {
                    AppState.selectedActions.delete('unfollow');
                    document.querySelector('[data-action="unfollow"]')?.classList.remove('active');
                }
            } else {
                AppState.selectedActions.delete(action);
            }
            console.log('Selected Actions:', Array.from(AppState.selectedActions));
        });
    });
}

// --- DROPDOWNS ---
function initDropdowns() {
    // Toggle Menus
    document.getElementById('btnLoadMenu').onclick = (e) => toggleDropdown('menuLoad', e);
    document.getElementById('btnSelectMenu').onclick = (e) => toggleDropdown('menuSelect', e);

    // Close on click outside
    document.addEventListener('click', (e) => {
        if (!e.target.closest('.dropdown')) {
            document.querySelectorAll('.dropdown').forEach(d => d.classList.remove('open'));
        }
    });

    // Load Actions
    document.querySelectorAll('#menuLoad button').forEach(btn => {
        btn.onclick = () => {
            const type = btn.dataset.load;
            const limit = parseInt(prompt("Quantas contas carregar?", "200")) || 200;
            loadAccounts(type, limit);
        };
    });
}

function toggleDropdown(id, e) {
    e.stopPropagation(); // Prevent immediate close
    const dropdown = document.getElementById(id).parentElement;
    document.querySelectorAll('.dropdown').forEach(d => {
        if (d !== dropdown) d.classList.remove('open');
    });
    dropdown.classList.toggle('open');
}

// --- CORE CONTROLS ---
function initControls() {
    document.getElementById('btnStart').onclick = () => {
        if (AppState.selectedActions.size === 0) return alert("Selecione pelo menos uma ação (ex: Seguir)");
        if (AppState.accounts.length === 0) return alert("Carregue uma lista de contas primeiro!");

        sendMessage('startAutomation', {
            targets: AppState.accounts.map(a => a.username),
            actions: Array.from(AppState.selectedActions),
            options: {
                delayMin: document.getElementById('cfgDelayMin').value,
                delayMax: document.getElementById('cfgDelayMax').value
            }
        });
        updateStatusUI('running');
    };

    document.getElementById('btnPause').onclick = () => sendMessage('pauseAutomation');
    document.getElementById('btnStop').onclick = () => sendMessage('stopAutomation');

    document.getElementById('btnRefresh').onclick = () => chrome.runtime.reload();
}

// --- API ACTIONS ---
function loadAccounts(type, limit) {
    addLog('info', `📥 Carregando ${limit} ${type}... aguarde.`);

    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        const tab = tabs[0];
        if (!tab || !tab.url.includes('instagram.com')) {
            return alert("Abra uma aba do Instagram para carregar!");
        }

        // Send to Content Script to extract via API
        chrome.tabs.sendMessage(tab.id, {
            action: 'extract_api',
            type: type, // 'followers', 'following'
            limit: limit,
            username: document.getElementById('targetProfile').textContent.replace('@', '')
        }, (response) => {
            if (chrome.runtime.lastError) return addLog('error', "Erro de conexão. Atualize a página e tente novamente.");
            if (response && response.success) {
                // Filter followed logic moved here
                let accounts = response.data;
                const filterFollowed = document.getElementById('cfgSkipFollowed').checked;

                if (filterFollowed && (type === 'followers' || type === 'likers')) {
                    const before = accounts.length;
                    accounts = accounts.filter(a => !a.followed_by_viewer && !a.requested_by_viewer);
                    const removed = before - accounts.length;
                    if (removed > 0) addLog('success', `🔍 ${removed} perfis que já segue removidos.`);
                }

                AppState.accounts = accounts;
                renderAccounts();
                addLog('success', `✅ ${accounts.length} contas carregadas!`);

                // Update Badge
                document.getElementById('progressText').textContent = `${accounts.length} contas prontas`;
            } else {
                addLog('error', `Falha: ${response?.message || 'Erro desconhecido'}`);
            }
        });
    });
}

// --- RENDER ---
function renderAccounts() {
    const list = document.getElementById('accountsList');
    list.innerHTML = '';

    if (AppState.accounts.length === 0) {
        list.innerHTML = `<div class="empty-state"><p>Lista vazia</p></div>`;
        return;
    }

    AppState.accounts.forEach(acc => {
        const item = document.createElement('div');
        item.className = 'account-item';
        // Fallback image handling
        const imgUrl = acc.profile_pic_url || 'https://ui-avatars.com/api/?name=' + acc.username;

        item.innerHTML = `
            <img src="${imgUrl}" class="acc-avatar">
            <div class="acc-info">
                <div class="acc-username">@${acc.username}</div>
                <div class="acc-fullname">${acc.full_name || ''}</div>
            </div>
            <div id="status-${acc.username}">
                <span class="status-badge badge-pending">PENDENTE</span>
            </div>
        `;
        list.appendChild(item);
    });

    document.getElementById('progressCount').textContent = `0/${AppState.accounts.length}`;
}

// --- INSTAGRAM DETECTION ---
function detectInstagramProfile() {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs[0] && tabs[0].url.includes('instagram.com')) {
            // Simple regex to get username from URL
            const urlParts = tabs[0].url.split('/');
            const username = urlParts[3];
            if (username && !['direct', 'explore', 'reels'].includes(username)) {
                const cleanUser = username.split('?')[0];
                document.getElementById('targetProfile').textContent = '@' + cleanUser;
                document.querySelector('.status-dot').classList.add('online');
            }
        }
    });
}

// --- COMMUNICATION ---
function sendMessage(action, data = {}) {
    chrome.runtime.sendMessage({ action, data }, (response) => {
        console.log(`[E.I.O] ${action} sent. Response:`, response);
    });
}

// --- UPDATE UI FROM STATE ---
function updateUI(state) {
    if (state.isRunning) updateStatusUI('running');
    else updateStatusUI('idle');

    // Resume queue if exists (re-render not fully needed if kept in memory, but good for refresh)
    // Here we assume state is managed by popup memory for simplicity in v1
}

function updateStatusUI(status) {
    const btnStart = document.getElementById('btnStart');
    const btnPause = document.getElementById('btnPause');
    const btnStop = document.getElementById('btnStop');

    if (status === 'running') {
        btnStart.disabled = true;
        btnPause.disabled = false;
        btnStop.disabled = false;
        btnStart.innerHTML = '<span class="symbol">⌛</span> RODANDO...';
    } else {
        btnStart.disabled = false;
        btnPause.disabled = true;
        btnStop.disabled = true;
        btnStart.innerHTML = '<span class="symbol">▶</span> INICIAR';
    }
    AppState.isRunning = (status === 'running');
}

function addLog(type, msg) {
    const box = document.getElementById('consoleLogs');
    const line = document.createElement('div');
    line.className = `log-line ${type}`;
    line.innerHTML = `<span class="timestamp">[${new Date().toLocaleTimeString()}]</span> ${msg}`;
    box.prepend(line);
}

// --- LISTENER FROM BACKGROUND ---
chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === 'consoleMessage') {
        addLog(msg.level, msg.message);
    }
    if (msg.type === 'actionCompleted') {
        // Update specific item in grid
        const badge = document.querySelector(`#status-${msg.username} span`);
        if (badge) {
            badge.textContent = msg.action.toUpperCase();
            badge.className = `status-badge badge-${msg.action}`; // badge-followed, badge-error
        }
    }
    if (msg.type === 'automationStopped') {
        updateStatusUI('idle');
        addLog('info', '✅ Automação finalizada.');
    }
});

function initKeepAlive() { setInterval(() => chrome.runtime.sendMessage({ action: 'ping' }), 20000); }

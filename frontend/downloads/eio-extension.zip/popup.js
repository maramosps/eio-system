/*
═══════════════════════════════════════════════════════════
  E.I.O - EXTENSION POPUP LOGIC
  Controle da interface da extensão
═══════════════════════════════════════════════════════════
*/

// Estado global da extensão
let extensionState = {
    isRunning: false,
    stats: {
        followsToday: 0,
        likesToday: 0,
        commentsToday: 0
    },
    automations: [],
    connectionStatus: 'connected',
    extractedLeads: [],
    lastExtractSource: 'followers',
    lastTargetProfile: '',
    lastExtractTarget: '',
    lastFilters: {}
};

// Função para salvar estado no chrome.storage (persistência)
async function saveExtensionState() {
    if (typeof chrome !== 'undefined' && chrome.storage) {
        try {
            await chrome.storage.local.set({ extensionState });
            console.log('📦 Estado salvo com sucesso');
        } catch (e) {
            console.error('Erro ao salvar estado:', e);
        }
    }
}

// Listener para receber logs do content script
if (typeof chrome !== 'undefined' && chrome.runtime) {
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
        if (message.action === 'console_log') {
            // Receber log do content script e exibir no console da extensão
            addConsoleEntry(message.level, message.message);
        }
        return false;
    });
}

// Inicialização robusta COM VERIFICAÇÃO DE LICENÇA
document.addEventListener('DOMContentLoaded', async () => {
    console.log('E.I.O Popup DOM Loaded');

    // ═══════════════════════════════════════════════════════════
    // VERIFICAÇÃO DE LICENÇA - PRIMEIRA PRIORIDADE
    // ═══════════════════════════════════════════════════════════
    if (typeof window.licenseManager !== 'undefined') {
        console.log('🔐 Verificando licença...');
        const isLicenseValid = await window.licenseManager.initialize();

        if (!isLicenseValid) {
            console.warn('❌ Licença inválida ou expirada - Bloqueando extensão');
            // License Manager já mostra o modal e bloqueia a UI
            return; // NÃO CONTINUAR A INICIALIZAÇÃO
        }

        console.log('✅ Licença válida - Inicializando extensão');
    } else {
        console.error('⚠️ License Manager não encontrado!');
    }

    // ═══════════════════════════════════════════════════════════
    // INICIALIZAÇÃO NORMAL (apenas se licença válida)
    // ═══════════════════════════════════════════════════════════

    // Inicializar abas primeiro para garantir navegabilidade
    initializeTabs();

    // Tentar carregar estado e inicializar o resto
    try {
        if (typeof chrome !== 'undefined' && chrome.storage) {
            await loadSavedState();
            await checkTermsApproval();
            autoDetectTarget();
            startLiveUpdates();
        } else {
            console.warn('Executando fora do contexto de extensão. Usando modo de demonstração.');
            // Simular estado para preview
            const extractionResults = document.getElementById('extractionResults');
            if (extractionResults) extractionResults.style.display = 'none';
        }
    } catch (e) {
        console.error('Erro na inicialização segura:', e);
    }

    initializeButtons();
    updateUI();

    // Atualizar UIs dinâmicas
    updateStatsUI();
    updateHistoryUI();
    loadConsoleLogs();

    // Inicializar Flow Builder integrado
    setTimeout(() => {
        if (typeof initializeFlowBuilder === 'function') {
            initializeFlowBuilder();
        }
    }, 500);
});

/**
 * Adicionar entrada no console da extensão
 */
function addConsoleEntry(level, message) {
    const consoleLog = document.getElementById('consoleLog');
    if (!consoleLog) return;

    const time = new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit', second: '2-digit' });

    const entry = document.createElement('div');
    entry.className = `eio-console-entry eio-console-${level}`;

    const icons = {
        'success': '✅',
        'error': '❌',
        'warning': '⚠️',
        'info': 'ℹ️'
    };

    entry.innerHTML = `
        <span class="eio-console-time">${time}</span>
        <span class="eio-console-icon">${icons[level] || '📌'}</span>
        <span class="eio-console-msg">${message}</span>
    `;

    consoleLog.prepend(entry);

    // Limitar a 50 entradas
    while (consoleLog.children.length > 50) {
        consoleLog.lastChild.remove();
    }

    // Salvar logs
    saveConsoleLogs();
}

/**
 * Salvar logs do console
 */
async function saveConsoleLogs() {
    if (typeof chrome === 'undefined' || !chrome.storage) return;

    const consoleLog = document.getElementById('consoleLog');
    if (!consoleLog) return;

    const logs = Array.from(consoleLog.children).slice(0, 30).map(el => el.outerHTML);

    try {
        await chrome.storage.local.set({ consoleLogs: logs });
    } catch (e) {
        console.error('Erro ao salvar logs:', e);
    }
}

/**
 * Carregar logs do console salvos
 */
async function loadConsoleLogs() {
    if (typeof chrome === 'undefined' || !chrome.storage) return;

    try {
        const result = await chrome.storage.local.get(['consoleLogs']);
        if (result.consoleLogs && result.consoleLogs.length > 0) {
            const consoleLog = document.getElementById('consoleLog');
            if (consoleLog) {
                consoleLog.innerHTML = result.consoleLogs.join('');
            }
        }
    } catch (e) {
        console.error('Erro ao carregar logs:', e);
    }
}

/**
 * Limpar console
 */
function clearConsole() {
    const consoleLog = document.getElementById('consoleLog');
    if (consoleLog) {
        consoleLog.innerHTML = '';
        saveConsoleLogs();
        showToast('🗑️ Console limpo', 'info');
    }
}

/**
 * Autodetectar o perfil ou post atual e exibir card de perfil
 */
async function autoDetectTarget() {
    if (typeof chrome === 'undefined' || !chrome.tabs) return;

    try {
        const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
        if (tabs[0] && tabs[0].url.includes('instagram.com')) {
            const url = tabs[0].url;
            const targetInput = document.getElementById('extractTarget');
            const targetProfile = document.getElementById('targetProfile');
            const sourceSelect = document.getElementById('extractSource');
            const profileCard = document.getElementById('currentProfileCard');

            if (url.includes('/p/') || url.includes('/reels/')) {
                if (targetInput) targetInput.value = url;
                if (sourceSelect) sourceSelect.value = 'likes';
                if (profileCard) profileCard.style.display = 'none';
            } else {
                const profileMatch = url.match(/instagram\.com\/([^/?#&]+)/);
                if (profileMatch && !['explore', 'reels', 'direct', 'stories', 'accounts'].includes(profileMatch[1])) {
                    const username = profileMatch[1];
                    if (targetInput) targetInput.value = `@${username}`;
                    if (targetProfile) targetProfile.value = `@${username}`;
                    if (sourceSelect) sourceSelect.value = 'followers';

                    // Atualizar card de perfil
                    updateCurrentProfileCard(username);

                    // Salvar perfil atual no estado
                    extensionState.currentProfile = username;
                    saveExtensionState();
                } else {
                    if (profileCard) profileCard.style.display = 'none';
                }
            }
        }
    } catch (e) { console.error('AutoDetect failed', e); }
}

/**
 * Atualizar card de perfil atual
 */
function updateCurrentProfileCard(username) {
    const profileCard = document.getElementById('currentProfileCard');
    const profileName = document.getElementById('currentProfileName');
    const profileUsername = document.getElementById('currentProfileUsername');

    if (profileCard) {
        profileCard.style.display = 'flex';
    }
    if (profileName) {
        profileName.textContent = username.charAt(0).toUpperCase() + username.slice(1);
    }
    if (profileUsername) {
        profileUsername.textContent = `@${username}`;
    }
}

// Carregar estado salvo
async function loadSavedState() {
    if (typeof chrome === 'undefined' || !chrome.storage) return;
    try {
        const result = await chrome.storage.local.get(['extensionState']);
        if (result.extensionState) {
            extensionState = { ...extensionState, ...result.extensionState };

            // Restaurar campos do formulário
            const sourceSelect = document.getElementById('extractSource');
            const targetProfile = document.getElementById('targetProfile');
            const extractTarget = document.getElementById('extractTarget');

            if (sourceSelect && extensionState.lastExtractSource) {
                sourceSelect.value = extensionState.lastExtractSource;
            }
            if (targetProfile && extensionState.lastTargetProfile) {
                targetProfile.value = extensionState.lastTargetProfile;
            }
            if (extractTarget && extensionState.lastExtractTarget) {
                extractTarget.value = extensionState.lastExtractTarget;
            }

            // Restaurar filtros
            if (extensionState.lastFilters) {
                const filterBR = document.getElementById('filterBR');
                const filterPhoto = document.getElementById('filterPhoto');
                const filterPosts = document.getElementById('filterPosts');
                const filterPublic = document.getElementById('filterPublic');

                if (filterBR) filterBR.checked = extensionState.lastFilters.brOnly ?? true;
                if (filterPhoto) filterPhoto.checked = extensionState.lastFilters.hasPhoto ?? true;
                if (filterPosts) filterPosts.checked = extensionState.lastFilters.minPosts ?? false;
                if (filterPublic) filterPublic.checked = extensionState.lastFilters.publicOnly ?? false;
            }

            // Restaurar leads extraídos
            if (extensionState.extractedLeads && extensionState.extractedLeads.length > 0) {
                updateResultsUI();
            }

            console.log('📂 Estado restaurado com sucesso:', extensionState);
        }

        // Configurar auto-save dos campos
        setupAutoSaveFields();

    } catch (error) {
        console.error('Error loading state:', error);
    }
}

/**
 * Configurar auto-save dos campos do formulário
 */
function setupAutoSaveFields() {
    // Salvar fonte de extração
    const sourceSelect = document.getElementById('extractSource');
    if (sourceSelect) {
        sourceSelect.addEventListener('change', () => {
            extensionState.lastExtractSource = sourceSelect.value;
            saveExtensionState();
        });
    }

    // Salvar perfil alvo
    const targetProfile = document.getElementById('targetProfile');
    if (targetProfile) {
        targetProfile.addEventListener('input', debounce(() => {
            extensionState.lastTargetProfile = targetProfile.value;
            saveExtensionState();
        }, 500));
    }

    // Salvar alvo/referência
    const extractTarget = document.getElementById('extractTarget');
    if (extractTarget) {
        extractTarget.addEventListener('input', debounce(() => {
            extensionState.lastExtractTarget = extractTarget.value;
            saveExtensionState();
        }, 500));
    }

    // Salvar filtros
    ['filterBR', 'filterPhoto', 'filterPosts', 'filterPublic'].forEach(id => {
        const el = document.getElementById(id);
        if (el) {
            el.addEventListener('change', () => {
                extensionState.lastFilters = {
                    brOnly: document.getElementById('filterBR')?.checked ?? true,
                    hasPhoto: document.getElementById('filterPhoto')?.checked ?? true,
                    minPosts: document.getElementById('filterPosts')?.checked ?? false,
                    publicOnly: document.getElementById('filterPublic')?.checked ?? false
                };
                saveExtensionState();
            });
        }
    });

    console.log('✓ Auto-save configurado');
}

/**
 * Função debounce para evitar salvamentos excessivos
 */
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Sistema de navegação por abas
function initializeTabs() {
    const tabs = document.querySelectorAll('.eio-tab');
    const contents = document.querySelectorAll('.eio-tab-content');

    tabs.forEach(tab => {
        tab.addEventListener('click', (e) => {
            e.preventDefault();
            const targetTab = tab.getAttribute('data-tab');
            console.log('Switching to tab:', targetTab);

            tabs.forEach(t => t.classList.remove('eio-tab-active'));
            contents.forEach(c => c.classList.remove('eio-tab-content-active'));

            tab.classList.add('eio-tab-active');
            const targetContent = document.getElementById(`${targetTab}Tab`);
            if (targetContent) {
                targetContent.classList.add('eio-tab-content-active');
            }
        });
    });
}

// Inicializar botões com segurança
function safeAddEventListener(id, event, fn) {
    const el = document.getElementById(id);
    if (el) {
        el.addEventListener(event, fn);
        console.log(`✓ Listener adicionado: #${id}`);
    } else {
        console.warn(`⚠ Elemento #${id} não encontrado`);
    }
}

function initializeButtons() {
    safeAddEventListener('startAutomationBtn', 'click', startAutomation);
    safeAddEventListener('pauseAutomationBtn', 'click', pauseAutomation);
    safeAddEventListener('clearConsoleBtn', 'click', clearConsole);
    safeAddEventListener('startExtractionBtn', 'click', startExtraction);
    safeAddEventListener('sendToCrmBtn', 'click', sendLeadsToCRM);
    safeAddEventListener('executeSelectedBtn', 'click', executeActionOnSelected);

    safeAddEventListener('selectAllLeads', 'change', (e) => toggleSelectAll(e.target.checked));
    safeAddEventListener('deselectLast50', 'click', () => deselectLastN(50));
    safeAddEventListener('deselectLast100', 'click', () => deselectLastN(100));
    safeAddEventListener('clearSelection', 'click', () => toggleSelectAll(false));

    safeAddEventListener('settingsBtn', 'click', () => {
        console.log('⚙️ Settings button clicked');

        // Criar modal de configurações se não existir
        let settingsModal = document.getElementById('settingsModal');
        if (!settingsModal) {
            settingsModal = document.createElement('div');
            settingsModal.id = 'settingsModal';
            settingsModal.className = 'eio-terms-modal';
            settingsModal.innerHTML = `
                <div class="eio-terms-content" style="max-width: 400px;">
                    <span class="eio-terms-title">⚙️ Configurações</span>
                    <div style="text-align: left; margin: 20px 0;">
                        <div style="margin-bottom: 16px;">
                            <label style="display: block; color: rgba(255,255,255,0.6); font-size: 0.75rem; margin-bottom: 8px; text-transform: uppercase;">Velocidade de Ação</label>
                            <select class="eio-input" id="speedSetting" style="width: 100%;">
                                <option value="safe">Humana (Segura - Recomendado)</option>
                                <option value="fast">Rápida (Contas antigas)</option>
                                <option value="turbo">Turbo (Alto risco)</option>
                            </select>
                        </div>
                        <div style="margin-bottom: 16px;">
                            <label style="display: flex; align-items: center; gap: 10px; cursor: pointer;">
                                <input type="checkbox" id="autoStartSetting" style="width: 18px; height: 18px;">
                                <span style="color: white; font-size: 0.9rem;">Iniciar automação ao abrir</span>
                            </label>
                        </div>
                        <div style="margin-bottom: 16px;">
                            <label style="display: flex; align-items: center; gap: 10px; cursor: pointer;">
                                <input type="checkbox" id="notificationsSetting" checked style="width: 18px; height: 18px;">
                                <span style="color: white; font-size: 0.9rem;">Notificações de ações</span>
                            </label>
                        </div>
                    </div>
                    <div style="display: flex; gap: 10px;">
                        <button class="eio-btn eio-btn-ghost" style="flex: 1;" id="cancelSettingsBtn">Cancelar</button>
                        <button class="eio-btn eio-btn-primary" style="flex: 1;" id="saveSettingsBtn">Salvar</button>
                    </div>
                </div>
            `;
            document.body.appendChild(settingsModal);

            // Adicionar event listeners
            document.getElementById('cancelSettingsBtn').addEventListener('click', () => {
                document.getElementById('settingsModal').style.display = 'none';
            });
            document.getElementById('saveSettingsBtn').addEventListener('click', saveSettings);
        }

        // Mostrar modal
        settingsModal.style.display = 'flex';

        if (typeof showToast === 'function') {
            showToast('⚙️ Configurações abertas', 'info');
        }
    });

    safeAddEventListener('openDashboardBtn', 'click', () => {
        const url = 'dashboard.html'; // Usar local no preview ou full URL em prod
        if (typeof chrome !== 'undefined' && chrome.tabs) {
            chrome.tabs.create({ url: chrome.runtime.getURL('frontend/dashboard.html') });
        } else {
            window.open('../frontend/dashboard.html', '_blank');
        }
    });

    // Dashboard Link agora tem href direto no HTML com URL correta
    // Não precisa de handler de clique adicional

    safeAddEventListener('acceptTermsBtn', 'click', async () => {
        if (typeof chrome !== 'undefined' && chrome.storage) {
            const result = await chrome.storage.local.get(['extensionState']);
            const state = result.extensionState || extensionState;
            state.termsAccepted = true;
            await chrome.storage.local.set({ 'extensionState': state });
        }
        const modal = document.getElementById('termsModal');
        if (modal) modal.classList.remove('active');
    });

    // Fluxos - Atualizar
    safeAddEventListener('refreshFlowsBtn', 'click', loadActiveFlows);

    // Fluxos - Criar novo
    safeAddEventListener('createFlowBtn', 'click', () => {
        if (typeof chrome !== 'undefined' && chrome.tabs) {
            chrome.tabs.create({ url: chrome.runtime.getURL('frontend/flow-builder.html') });
        } else {
            window.open('../frontend/flow-builder.html', '_blank');
        }
    });

    // ═══════════════════════════════════════════════════════════
    // BOTÃO POP-OUT - Destacar janela fixa na tela
    // ═══════════════════════════════════════════════════════════
    safeAddEventListener('popoutBtn', 'click', () => {
        if (typeof chrome !== 'undefined' && chrome.windows) {
            chrome.windows.create({
                url: chrome.runtime.getURL('popup.html'),
                type: 'popup',
                width: 450,
                height: 650,
                top: 50,
                left: screen.width - 500
            });
            // Fechar popup atual
            window.close();
        } else {
            showToast('Pop-out disponível apenas na extensão', 'warning');
        }
    });

    // ═══════════════════════════════════════════════════════════
    // AÇÕES RÁPIDAS
    // ═══════════════════════════════════════════════════════════
    safeAddEventListener('quickFollowBtn', 'click', async () => {
        showToast('🔄 Seguindo perfil...', 'info');
        await executeQuickAction('follow');
    });

    safeAddEventListener('quickLikeBtn', 'click', async () => {
        showToast('🔄 Curtindo posts...', 'info');
        await executeQuickAction('like');
    });

    safeAddEventListener('quickDmBtn', 'click', async () => {
        showToast('💬 Abrindo DM...', 'info');
        await executeQuickAction('dm');
    });

    safeAddEventListener('quickExtractBtn', 'click', () => {
        // Mudar para aba Assistente e iniciar
        document.querySelector('[data-tab="assistant"]')?.click();
        showToast('📥 Vá para a aba Assistente para extrair', 'info');
    });

    // Limpar histórico
    safeAddEventListener('clearHistoryBtn', 'click', () => {
        extensionState.actionHistory = [];
        saveExtensionState();
        updateHistoryUI();
        showToast('🗑️ Histórico limpo', 'success');
    });
}

/**
 * Executar ação rápida
 */
async function executeQuickAction(actionType) {
    if (typeof chrome === 'undefined' || !chrome.tabs) {
        showToast('Execute no Instagram', 'error');
        return;
    }

    try {
        const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
        if (!tabs[0] || !tabs[0].url.includes('instagram.com')) {
            showToast('Abra o Instagram primeiro', 'error');
            return;
        }

        const result = await chrome.tabs.sendMessage(tabs[0].id, {
            action: 'execute',
            payload: { type: actionType }
        });

        if (result && result.success) {
            addToHistory(actionType, extensionState.currentProfile || 'perfil');
            incrementStat(actionType);
            showToast(`✅ ${getActionLabel(actionType)} realizado!`, 'success');
        } else {
            showToast(`❌ Falha ao ${getActionLabel(actionType).toLowerCase()}`, 'error');
        }
    } catch (e) {
        console.error('Quick action error:', e);
        showToast('⚠️ Recarregue a página do Instagram', 'error');
    }
}

/**
 * Adicionar ação ao histórico
 */
function addToHistory(actionType, target) {
    if (!extensionState.actionHistory) {
        extensionState.actionHistory = [];
    }

    extensionState.actionHistory.unshift({
        type: actionType,
        target: target,
        time: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })
    });

    // Manter apenas últimas 20 ações
    if (extensionState.actionHistory.length > 20) {
        extensionState.actionHistory.pop();
    }

    saveExtensionState();
    updateHistoryUI();
}

/**
 * Atualizar UI do histórico
 */
function updateHistoryUI() {
    const container = document.getElementById('actionHistory');
    if (!container) return;

    if (!extensionState.actionHistory || extensionState.actionHistory.length === 0) {
        container.innerHTML = `
            <div class="eio-history-empty">
                <span>Nenhuma ação realizada ainda</span>
            </div>
        `;
        return;
    }

    const iconMap = {
        'follow': '👤',
        'like': '❤️',
        'comment': '💬',
        'dm': '✉️'
    };

    container.innerHTML = extensionState.actionHistory.map(item => `
        <div class="eio-history-item">
            <div class="eio-history-icon ${item.type}">${iconMap[item.type] || '📌'}</div>
            <span class="eio-history-text">${getActionLabel(item.type)} @${item.target}</span>
            <span class="eio-history-time">${item.time}</span>
        </div>
    `).join('');
}

/**
 * Incrementar estatística
 */
function incrementStat(actionType) {
    const today = new Date().toDateString();
    if (extensionState.statsDate !== today) {
        extensionState.stats = { followsToday: 0, likesToday: 0, commentsToday: 0, dmsToday: 0 };
        extensionState.statsDate = today;
    }

    switch (actionType) {
        case 'follow': extensionState.stats.followsToday++; break;
        case 'like': extensionState.stats.likesToday++; break;
        case 'comment': extensionState.stats.commentsToday++; break;
        case 'dm': extensionState.stats.dmsToday = (extensionState.stats.dmsToday || 0) + 1; break;
    }

    updateStatsUI();
    saveExtensionState();
}

/**
 * Atualizar UI de estatísticas
 */
function updateStatsUI() {
    const follows = document.getElementById('followsToday');
    const likes = document.getElementById('likesToday');
    const comments = document.getElementById('commentsToday');
    const dms = document.getElementById('dmsToday');
    const actionsToday = document.getElementById('actionsToday');

    if (follows) follows.textContent = extensionState.stats?.followsToday || 0;
    if (likes) likes.textContent = extensionState.stats?.likesToday || 0;
    if (comments) comments.textContent = extensionState.stats?.commentsToday || 0;
    if (dms) dms.textContent = extensionState.stats?.dmsToday || 0;

    const total = (extensionState.stats?.followsToday || 0) +
        (extensionState.stats?.likesToday || 0) +
        (extensionState.stats?.commentsToday || 0) +
        (extensionState.stats?.dmsToday || 0);
    if (actionsToday) actionsToday.textContent = total;
}

/**
 * Obter label da ação
 */
function getActionLabel(actionType) {
    const labels = {
        'follow': 'Seguido',
        'like': 'Curtido',
        'comment': 'Comentado',
        'dm': 'DM enviado'
    };
    return labels[actionType] || actionType;
}

/**
 * Mostrar toast de notificação
 */
function showToast(message, type = 'info') {
    let toast = document.getElementById('eio-toast');
    if (!toast) {
        toast = document.createElement('div');
        toast.id = 'eio-toast';
        toast.style.cssText = `
            position: fixed;
            bottom: 80px;
            left: 50%;
            transform: translateX(-50%);
            padding: 10px 20px;
            border-radius: 8px;
            font-size: 0.85rem;
            font-weight: 600;
            z-index: 9999;
            opacity: 0;
            transition: opacity 0.3s ease;
            max-width: 90%;
            text-align: center;
        `;
        document.body.appendChild(toast);
    }

    const colors = {
        'success': { bg: 'rgba(76, 175, 80, 0.95)', color: 'white' },
        'error': { bg: 'rgba(244, 67, 54, 0.95)', color: 'white' },
        'warning': { bg: 'rgba(255, 152, 0, 0.95)', color: 'white' },
        'info': { bg: 'rgba(33, 150, 243, 0.95)', color: 'white' }
    };

    const style = colors[type] || colors.info;
    toast.style.background = style.bg;
    toast.style.color = style.color;
    toast.textContent = message;
    toast.style.opacity = '1';

    setTimeout(() => {
        toast.style.opacity = '0';
    }, 2500);
}

/**
 * Verificar se os termos foram aceitos
 */
async function checkTermsApproval() {
    const result = await chrome.storage.local.get(['extensionState']);
    if (!result.extensionState || !result.extensionState.termsAccepted) {
        document.getElementById('termsModal').classList.add('active');
    }
}

// Iniciar extração de leads
async function startExtraction() {
    const source = document.getElementById('extractSource').value;
    const targetProfile = document.getElementById('targetProfile')?.value || '';
    const extractTarget = document.getElementById('extractTarget')?.value || '';

    // Determinar o alvo correto baseado no tipo de fonte
    let target = extractTarget;
    if ((source === 'followers' || source === 'following') && targetProfile) {
        target = targetProfile;
    }

    // Coletar Filtros (Resiliente a elementos faltantes)
    const filters = {
        brOnly: document.getElementById('filterBR')?.checked || false,
        hasPhoto: document.getElementById('filterPhoto')?.checked || false,
        minPosts: document.getElementById('filterPosts')?.checked || false,
        publicOnly: document.getElementById('filterPublic')?.checked || false
    };

    if (!target) {
        addConsoleEntry('error', 'Por favor, informe o alvo da extração (perfil ou referência)');
        return;
    }

    // Salvar configurações para persistência
    extensionState.lastExtractSource = source;
    extensionState.lastTargetProfile = targetProfile;
    extensionState.lastExtractTarget = extractTarget;
    extensionState.lastFilters = filters;
    await saveExtensionState();

    try {
        extensionState.extractedLeads = [];
        updateResultsUI();

        document.getElementById('extractionProgress').style.display = 'block';
        document.getElementById('extractionResults').style.display = 'none';

        updateExtractionProgress(5, 0);

        const sourceLabels = {
            'followers': 'seguidores',
            'following': 'seguindo',
            'likes': 'curtidas',
            'hashtags': 'hashtag',
            'unfollow': 'deixar de seguir'
        };
        addConsoleEntry('info', `Solicitando extração de ${sourceLabels[source] || source}...`);

        const tabs = await chrome.tabs.query({ active: true, currentWindow: true });

        // Definir Limite (200 para seguidores/curtidas, 500 para unfollow)
        const limit = source === 'unfollow' ? 500 : 200;

        const result = await chrome.tabs.sendMessage(tabs[0].id, {
            action: 'execute_extraction',
            payload: {
                type: source,
                value: target,
                filters: filters,
                limit: limit
            }
        });

        if (result && result.success) {
            // Adicionar flag de selecionado por padrão
            extensionState.extractedLeads = result.data.map(lead => ({ ...lead, selected: true }));
            updateExtractionProgress(100, result.data.length);
            updateResultsUI();
            addConsoleEntry('success', `Extração concluída: ${result.data.length} leads.`);

            // Salvar leads extraídos
            await saveExtensionState();
        } else {
            updateExtractionProgress(0, 0);
            addConsoleEntry('error', `Falha: ${result ? result.message : 'Sem resposta'}`);
        }
    } catch (error) {
        console.error('Extraction error:', error);
        addConsoleEntry('error', '⚠️ Erro de comunicação. RECARREGUE o Instagram (F5).');
    }
}

// Atualizar barra de progresso
function updateExtractionProgress(percent, count) {
    const fill = document.getElementById('extractionProgressFill');
    const countEl = document.getElementById('extractionCount');
    if (fill) fill.style.width = `${percent}%`;
    if (countEl) countEl.innerText = `${count} leads`;
}

// Ouvir progresso em tempo real
chrome.runtime.onMessage.addListener((message) => {
    if (message.action === 'extraction_progress') {
        const percent = Math.min(message.count * 2, 98);
        updateExtractionProgress(percent, message.count);
    }
});

// Ações de Seleção Manual
function toggleSelectAll(checked) {
    extensionState.extractedLeads.forEach(l => l.selected = checked);
    if (document.getElementById('selectAllLeads')) {
        document.getElementById('selectAllLeads').checked = checked;
    }
    updateResultsUI();
}

function deselectLastN(n) {
    const leads = extensionState.extractedLeads;
    for (let i = Math.max(0, leads.length - n); i < leads.length; i++) {
        leads[i].selected = false;
    }
    updateResultsUI();
}

// Atualizar lista de resultados com Inteligência Visual
function updateResultsUI() {
    const container = document.getElementById('extractionResults');
    const list = document.getElementById('resultsList');
    const selectedCountEl = document.getElementById('selectedCount');
    const controls = document.querySelector('.eio-results-controls');
    const source = document.getElementById('extractSource')?.value || 'followers';
    const isUnfollow = source === 'unfollow';

    if (!extensionState.extractedLeads || extensionState.extractedLeads.length === 0) {
        if (container) container.style.display = 'none';
        return;
    }

    if (container) container.style.display = 'block';
    if (list) list.innerHTML = '';

    // Mostrar ou esconder controles de seleção (Só para Unfollow)
    if (controls) {
        controls.style.display = isUnfollow ? 'flex' : 'none';
    }

    let selectedCount = 0;

    extensionState.extractedLeads.forEach((lead, index) => {
        if (lead.selected) selectedCount++;

        const item = document.createElement('div');
        item.className = 'eio-lead-item';

        // Renderizar com ou sem checkbox baseado na funcionalidade
        const checkboxHtml = isUnfollow ?
            `<input type="checkbox" ${lead.selected ? 'checked' : ''} data-index="${index}">` :
            '';

        // Tratamento melhorado para avatares - usar placeholder quando imagem não carrega
        const getAvatarHtml = (lead) => {
            if (!lead.avatar || lead.avatar === '' || lead.avatar === 'undefined') {
                // Avatar padrão com inicial do nome
                const initial = (lead.name || lead.username || 'U').charAt(0).toUpperCase();
                return `<div class="eio-lead-avatar eio-lead-avatar-placeholder">${initial}</div>`;
            }
            // Tentar carregar imagem com fallback
            return `<img src="${lead.avatar}" 
                         class="eio-lead-avatar-img" 
                         onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';" 
                         alt="${lead.name || 'Avatar'}">
                    <div class="eio-lead-avatar eio-lead-avatar-placeholder" style="display:none;">
                        ${(lead.name || lead.username || 'U').charAt(0).toUpperCase()}
                    </div>`;
        };

        item.innerHTML = `
            ${checkboxHtml}
            <div class="eio-lead-avatar-container">
                ${getAvatarHtml(lead)}
            </div>
            <div class="eio-lead-info">
                <span class="eio-lead-name">${lead.name || 'Usuário Instagram'}</span>
                <span class="eio-lead-username">${lead.username || '@unknown'}</span>
            </div>
        `;

        if (isUnfollow) {
            const checkbox = item.querySelector('input');
            if (checkbox) {
                checkbox.onchange = (e) => {
                    extensionState.extractedLeads[index].selected = e.target.checked;
                    updateSelectedCount();
                    saveExtensionState(); // Salvar ao mudar seleção
                };
            }
        }

        if (list) list.appendChild(item);
    });

    if (selectedCountEl) {
        selectedCountEl.style.display = isUnfollow ? 'block' : 'none';
        selectedCountEl.innerText = `${selectedCount} selecionados`;
    }
}

function updateSelectedCount() {
    const count = extensionState.extractedLeads.filter(l => l.selected).length;
    const el = document.getElementById('selectedCount');
    const source = document.getElementById('extractSource').value;
    if (el) {
        el.style.display = source === 'unfollow' ? 'block' : 'none';
        el.innerText = `${count} selecionados`;
    }
}

// ENVIAR AÇÕES PARA O ROBÔ (O GRANDE BOTÃO START)
async function executeActionOnSelected() {
    const selectedLeads = extensionState.extractedLeads.filter(l => l.selected);
    const source = document.getElementById('extractSource').value;

    if (selectedLeads.length === 0) {
        addConsoleEntry('warning', 'Nenhum perfil selecionado para ação.');
        return;
    }

    addConsoleEntry('info', `Preparando ${selectedLeads.length} ações de ${source}...`);

    const actionType = source === 'unfollow' ? 'unfollow' : 'follow';

    const actions = selectedLeads.map(lead => ({
        type: actionType,
        target: { type: 'profile', value: lead.username.replace('@', '') },
        delay: Math.floor(Math.random() * (45000 - 30000 + 1) + 30000) // 30-45s entre ações para segurança
    }));

    try {
        const response = await chrome.runtime.sendMessage({
            action: 'loadQueue',
            payload: { actions: actions }
        });

        if (response && response.success) {
            addConsoleEntry('success', `${actions.length} perfis enviados para a fila!`);

            // Mudar para a aba Dashboard
            const dashTab = document.querySelector('[data-tab="dashboard"]');
            if (dashTab) dashTab.click();

            // Iniciar automação
            startAutomation();
        }
    } catch (error) {
        console.error('Error loading queue:', error);
        addConsoleEntry('error', 'Falha ao enviar perfis para o motor de automação.');
    }
}

// Enviar leads para o CRM
async function sendLeadsToCRM() {
    const count = extensionState.extractedLeads.length;
    addConsoleEntry('info', `Enviando ${count} leads para o CRM...`);
    await new Promise(r => setTimeout(r, 1500));
    addConsoleEntry('success', 'Leads integrados ao CRM com sucesso!');
    extensionState.extractedLeads = [];
    updateResultsUI();
    document.getElementById('extractionProgress').style.display = 'none';
}

// Automação
async function startAutomation() {
    extensionState.isRunning = true;
    await chrome.runtime.sendMessage({ action: 'startAutomation' });
    updateUI();
    addConsoleEntry('success', 'Automação iniciada');
}

async function pauseAutomation() {
    extensionState.isRunning = false;
    await chrome.runtime.sendMessage({ action: 'pauseAutomation' });
    updateUI();
    addConsoleEntry('warning', 'Automação pausada');
}

// Console
function addConsoleEntry(type, message) {
    const log = document.getElementById('consoleLog');
    if (!log) return;

    const entry = document.createElement('div');
    entry.className = `eio-log-entry log-${type}`;
    const time = new Date().toLocaleTimeString('pt-BR');
    entry.innerHTML = `<span class="eio-log-time">[${time}]</span><span class="eio-log-msg">${message}</span>`;
    log.prepend(entry);
}

function clearConsole() {
    const log = document.getElementById('consoleLog');
    if (log) log.innerHTML = '';
}

// Carregar fluxos ativos
async function loadActiveFlows() {
    const list = document.getElementById('activeFlowsList');
    const noFlows = document.getElementById('noFlowsMessage');
    if (!list) return;

    let flows = [];

    if (typeof chrome !== 'undefined' && chrome.runtime) {
        try {
            const response = await chrome.runtime.sendMessage({ action: 'getStatus' });
            if (response && response.currentFlow) {
                flows = [response.currentFlow];
            }
        } catch (e) { console.error('Error fetching flows', e); }
    } else {
        // Mock para preview
        flows = [
            { id: 1, name: 'Engajamento Orgânico #1', status: 'active' },
            { id: 2, name: 'Boas-vindas para Seguidores', status: 'paused' }
        ];
    }

    if (flows.length === 0) {
        list.style.display = 'none';
        if (noFlows) noFlows.style.display = 'flex';
    } else {
        list.style.display = 'block';
        if (noFlows) noFlows.style.display = 'none';

        list.innerHTML = flows.map(flow => `
            <div class="eio-flow-card">
                <div class="eio-flow-info">
                    <span class="eio-flow-name">${flow.name}</span>
                    <span class="eio-flow-status" style="color: ${flow.status === 'active' ? '#4CAF50' : '#FF9800'}">
                        ${flow.status === 'active' ? '✓ Rodando' : '⏳ Pausado'}
                    </span>
                </div>
                <div class="eio-flow-actions">
                    <button class="eio-btn-mini" onclick="toggleFlow(${flow.id})">${flow.status === 'active' ? 'Pausar' : 'Retomar'}</button>
                    <button class="eio-btn-mini eio-btn-mini-danger" onclick="stopFlow(${flow.id})">Parar</button>
                </div>
            </div>
        `).join('');
    }
}

window.toggleFlow = function (id) {
    console.log('Toggle flow:', id);
    alert('Ação enviada para o motor de automação.');
};

window.stopFlow = function (id) {
    if (confirm('Deseja realmente parar este fluxo?')) {
        console.log('Stop flow:', id);
        loadActiveFlows();
    }
};

// Reiniciar atualizações em tempo real
function startLiveUpdates() {
    loadActiveFlows();
    setInterval(async () => {
        if (typeof chrome !== 'undefined' && chrome.runtime) {
            try {
                const stats = await chrome.runtime.sendMessage({ action: 'getStats' });
                if (stats && stats.stats) {
                    const follows = document.getElementById('followsToday');
                    const likes = document.getElementById('likesToday');
                    const comments = document.getElementById('commentsToday');
                    if (follows) follows.innerText = stats.stats.followsToday || 0;
                    if (likes) likes.innerText = stats.stats.likesToday || 0;
                    if (comments) comments.innerText = stats.stats.commentsToday || 0;
                }
            } catch (e) { }
        }
    }, 3000);
}

// UI Updates
function updateUI() {
    const startBtn = document.getElementById('startAutomationBtn');
    const pauseBtn = document.getElementById('pauseAutomationBtn');
    if (startBtn) startBtn.disabled = extensionState.isRunning;
    if (pauseBtn) pauseBtn.disabled = !extensionState.isRunning;

    loadActiveFlows();
}

// NOTA: As funções safeAddEventListener para refreshFlowsBtn e createFlowBtn
// já estão definidas dentro de initializeButtons() (linhas 241-250)

// Função para salvar configurações
window.saveSettings = async function () {
    const speedSetting = document.getElementById('speedSetting')?.value || 'safe';
    const autoStart = document.getElementById('autoStartSetting')?.checked || false;
    const notifications = document.getElementById('notificationsSetting')?.checked || true;

    const settings = {
        speed: speedSetting,
        autoStart: autoStart,
        notifications: notifications,
        savedAt: new Date().toISOString()
    };

    console.log('💾 Salvando configurações:', settings);

    // Salvar no Chrome Storage se disponível
    if (typeof chrome !== 'undefined' && chrome.storage) {
        try {
            await chrome.storage.local.set({ settings });
        } catch (e) {
            console.log('Storage não disponível');
        }
    }

    // Fechar modal
    const modal = document.getElementById('settingsModal');
    if (modal) modal.style.display = 'none';

    // Feedback
    if (typeof showToast === 'function') {
        showToast('✅ Configurações salvas com sucesso!', 'success');
    }

    if (typeof addConsoleEntry === 'function') {
        addConsoleEntry('success', '✅ Configurações atualizadas');
    }
};

/*
  E.I.O Popup Logic v6.0 (Restoration)
  Foco: Persistência de Login e UX Premium
*/

document.addEventListener('DOMContentLoaded', async () => {
    // 1. Verificar Persistência Local (HD) para evitar loops
    const storage = await chrome.storage.local.get(['eio_auth_persistent', 'eio_user_cache']);

    if (storage.eio_auth_persistent) {
        // Login já foi validado antes. Liberar acesso imediato.
        console.log('[E.I.O] Login persistente detectado.');
        showAppScreen(storage.eio_user_cache);
        // Validar token em background apenas para atualizar dados, sem bloquear
        validateBackground(true);
    } else {
        // Primeira vez ou logout: Verificar com Background
        validateBackground(false);
    }

    setupEventListeners();
    loadDailyStats();
});

function validateBackground(isSilentUpdate) {
    chrome.runtime.sendMessage({ action: 'POPUP_QUERY_STATUS' }, (res) => {
        if (chrome.runtime.lastError) return;

        if (res && res.code === 'READY') {
            // Sucesso! Salvar persistência
            const userInfo = res.user || { username: 'Usuario' };
            chrome.storage.local.set({
                eio_auth_persistent: true,
                eio_user_cache: userInfo
            });

            if (!isSilentUpdate) showAppScreen(userInfo);
        } else {
            // Falha
            if (!isSilentUpdate) showLoginScreen();
        }
    });
}

// --- UI MANAGERS ---

function showAppScreen(user) {
    document.getElementById('loginScreen').classList.add('hidden');
    document.getElementById('appScreen').classList.remove('hidden');

    if (user) {
        const handle = user.instagram_handle || user.username || '@usuario';
        document.getElementById('userHandle').textContent = handle.startsWith('@') ? handle : '@' + handle;

        // Avatar Generativo Bonito
        const name = user.full_name || handle;
        document.getElementById('userAvatar').src = `https://ui-avatars.com/api/?name=${name}&background=25D366&color=fff&bold=true`;
    }
}

function showLoginScreen() {
    document.getElementById('appScreen').classList.add('hidden');
    document.getElementById('loginScreen').classList.remove('hidden');
}

function updateStats() {
    // Ler estatísticas de hoje do storage (atualizadas pelo background)
    chrome.storage.local.get(['stats_today'], (res) => {
        const stats = res.stats_today || { follows: 0, unfollows: 0 };

        // Seguir
        updateBar('barFollow', 'txtFollow', stats.follows, 200);
        // Deixar de Seguir
        updateBar('barUnfollow', 'txtUnfollow', stats.unfollows, 500);
    });
}

function updateBar(barId, txtId, current, max) {
    const pct = Math.min((current / max) * 100, 100);
    document.getElementById(barId).style.width = `${pct}%`;
    document.getElementById(txtId).textContent = `${current} / ${max}`;
}

// --- EVENT LISTENERS ---

function setupEventListeners() {
    // Login
    document.getElementById('btnLogin').onclick = () => {
        window.open('https://eio-system.vercel.app/login.html', '_blank');
    };

    document.getElementById('btnCheckLogin').onclick = () => {
        validateBackground(false);
    };

    // Botões de Ação
    bindAction('btnExtractFollowers', 'followers');
    bindAction('btnExtractFollowing', 'following');
    bindAction('btnExtractLikes', 'likers');
    bindAction('btnExtractComments', 'comments');
}

function bindAction(btnId, mode) {
    const btn = document.getElementById(btnId);
    if (!btn) return;

    btn.onclick = () => {
        // Feedback Visual de Clique
        btn.style.transform = 'scale(0.95)';
        setTimeout(() => btn.style.transform = 'translateY(-2px)', 150);

        // Enviar comando para Background -> Content
        chrome.runtime.sendMessage({
            action: 'EXECUTE_AUTOMATION',
            payload: { mode: mode }
        });

        // Fechar popup para não atrapalhar
        window.close();
    };
}

// Polling visual de stats
function loadDailyStats() {
    updateStats();
    setInterval(updateStats, 5000);
}

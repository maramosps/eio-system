/**
 * E.I.O SAFETY CONFIGURATION - ES MODULE
 * Protocolo de Segurança: v4.3.4 Refined
 * Status: Validação de Sintaxe OK
 */

export const EIO_SAFETY_CONFIG = {
    // Limites Diários (24h) - RÍGIDOS
    LIMITS: {
        DM_DAILY_MAX: 50,
        FOLLOW_DAILY_MAX: 200,
        UNFOLLOW_DAILY_MAX: 500,
        LIKE_DAILY_MIN: 40,
        LIKE_DAILY_MAX: 80
    },

    // Intervalos de Jitter (ms)
    DELAYS: {
        ACTION_MIN: 45000,   // 45s
        ACTION_MAX: 110000,  // 110s
        FOLLOW_BACK_DELAY: 60000
    },

    HUMANIZATION: {
        ENABLE_JITTER: true,
        SCROLL_BEFORE_ACTION: true,
        MOUSE_MOVEMENT_SIM: true
    }
};

/*
  E.I.O Auth Bridge v5.0
  Responsabilidade Única: Reportar identidade do usuário logado para a extensão.
  NÃO REALIZA REDIRECIONAMENTOS.
*/

console.log('[E.I.O Bridge] Ponte de Autenticação Ativa');

// Verificar periodicamente se há usuário logado e informar a extensão
function reportIdentity() {
    try {
        const userJson = localStorage.getItem('user');
        const token = localStorage.getItem('accessToken');

        if (userJson && token) {
            const user = JSON.parse(userJson);

            // Tenta pegar o @instagram do cadastro.
            // O campo pode variar dependendo do banco (instagram_handle, username, etc)
            // Vamos enviar o objeto user completo para o background decidir

            chrome.runtime.sendMessage({
                action: 'BRIDGE_IDENTITY_UPDATE',
                payload: {
                    isAuthenticated: true,
                    user: user,
                    token: token
                }
            }, (response) => {
                // Silently ignore errors (extension might not be listening yet)
                if (chrome.runtime.lastError) return;
            });
        }
    } catch (e) {
        // Silent fail
    }
}

// Reportar ao carregar
reportIdentity();

// Reportar a cada 5s (Heartbeat passivo)
setInterval(reportIdentity, 5000);

// Escutar pedidos da extensão
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.action === 'BRIDGE_QUERY_IDENTITY') {
        reportIdentity();
        sendResponse({ ack: true });
    }
});

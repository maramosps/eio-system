/*
  E.I.O Content Script v5.0 (Extraction Specialist)
  Foco: Identificar usuário e Extrair Leads.
  Module Logic: Dynamic Import for Safety Config
*/

let SAFETY = { DELAYS: { ACTION_MIN: 45000 } }; // Default fallback

// Importação Dinâmica do Módulo de Segurança
(async () => {
    try {
        const src = chrome.runtime.getURL('safety_config.js');
        const module = await import(src);
        SAFETY = module.EIO_SAFETY_CONFIG;
        console.log('[E.I.O] Safety Config Carregada:', SAFETY.LIMITS);
    } catch (e) {
        console.error('[E.I.O] Erro ao carregar Safety Config:', e);
    }
})();

console.log('[E.I.O] Extraction Module Ready');

// 1. AUTO-IDENTIFICAÇÃO
function identifyUser() {
    // Tenta pegar id numérico do cookie
    const cookieUser = getCookie('ds_user_id');

    // Tenta pegar username da barra lateral
    const profileLink = document.querySelector('a[href^="/"][role="link"] img[alt*="profile"]')?.closest('a');

    if (profileLink) {
        const username = profileLink.getAttribute('href').replace(/\//g, '');
        if (username) {
            chrome.runtime.sendMessage({
                action: 'INSTAGRAM_IDENTITY_UPDATE',
                payload: { username: username }
            });
        }
    }
}

// Tentar identificar a cada navegação
let lastUrl = location.href;
new MutationObserver(() => {
    if (location.href !== lastUrl) {
        lastUrl = location.href;
        identifyUser();
    }
}).observe(document, { subtree: true, childList: true });

setTimeout(identifyUser, 2000);
setTimeout(identifyUser, 5000);

// Escutar Background
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.action === 'REPORT_IDENTITY_NOW') identifyUser();

    if (msg.action === 'START_EXTRACTION') {
        // Se a config vier na mensagem, usa. Se não, usa a carregada localmente.
        const limits = msg.limits || SAFETY.LIMITS;
        const delays = msg.delays || SAFETY.DELAYS;
        startExtractionRoutine(msg.targetMode, limits, delays);
    }
});


// 2. ROTINA DE EXTRAÇÃO DE LEADS
async function startExtractionRoutine(mode, limits, delays) {
    console.log(`[E.I.O] Iniciando extração de ${mode}...`);

    const pathParts = location.pathname.split('/').filter(Boolean);
    if (pathParts.length !== 1) {
        alert("E.I.O: Por favor, navegue até o PERFIL do qual deseja extrair leads.");
        return;
    }

    const targetProfile = pathParts[0];

    // Abrir Modal
    const linkHref = mode === 'followers' ? `/${targetProfile}/followers/` : `/${targetProfile}/following/`;
    const link = document.querySelector(`a[href="${linkHref}"]`);

    if (!link) {
        alert(`E.I.O: Link de ${mode} não encontrado. O perfil pode ser privado ou bloqueado.`);
        return;
    }

    link.click();
    await sleep(3000);

    const modal = document.querySelector('div[role="dialog"] div[style*="overflow"]');
    if (!modal) {
        console.error("Modal de seguidores não abriu.");
        return;
    }

    let extracted = new Set();
    let fails = 0;
    const MAX_FAIL = 15;
    const LIMIT = 200;

    console.log("[E.I.O] Extraindo...");

    while (extracted.size < LIMIT && fails < MAX_FAIL) {
        const links = modal.querySelectorAll('a[href^="/"]');
        let newFound = 0;

        links.forEach(a => {
            const u = a.getAttribute('href').replaceAll('/', '');
            // Filtragem básica de user válido
            if (u && u !== targetProfile && !extracted.has(u) && u.length > 2) {
                extracted.add(u);
                newFound++;
                chrome.runtime.sendMessage({
                    action: 'LEAD_CAPTURED',
                    payload: { username: u, source: targetProfile, type: mode }
                });
            }
        });

        if (newFound === 0) fails++;
        else fails = 0;

        // Scroll com Jitter
        modal.scrollTop += 400 + Math.random() * 100;
        const delay = delays ? (delays.ACTION_MIN / 10) : 1000;
        await sleep(random(delay, delay * 2));
    }

    alert(`E.I.O: Extração concluída. ${extracted.size} leads capturados.`);
}

function getCookie(name) {
    const value = `; ${document.cookie}`;
    const parts = value.split(`; ${name}=`);
    if (parts.length === 2) return parts.pop().split(';').shift();
}
function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }
function random(min, max) { return Math.floor(Math.random() * (max - min) + min); }

/*
═══════════════════════════════════════════════════════════
  E.I.O - BACKGROUND SCRIPT (Service Worker)
  Motor de automação ultra-estável - VERSÃO 4.5.1 (FINAL SYNC)
  COM DELAYS INTELIGENTES + HARDCODED SAFETY
  + ACTION LOG MIDDLEWARE + HEARTBEAT + AUTO-FILTERS
═══════════════════════════════════════════════════════════
*/

console.log('[E.I.O Engine] ✅ Motor v4.5.1 Ativo');

const BACKEND_URL = 'https://eio-system.vercel.app';

let extensionState = {
    isRunning: false,
    isPausedForSafety: false,
    currentActionType: 'follow',
    currentOptions: {},
    stats: {
        followsToday: 0, likesToday: 0, commentsToday: 0,
        storiesLikedToday: 0, unfollowsToday: 0, dmsToday: 0,
        totalActionsToday: 0, sessionStartTime: null
    },
    limits: {
        maxFollowsPerDay: 200, maxUnfollowsPerDay: 500,
        maxLikesPerDay: 300, maxTotalActionsPerDay: 1000,
        actionsBeforePause: 25, pauseDurationMinutes: 60
    },
    actionsInCurrentBatch: 0,
    queue: [],
    activeTabId: null,
    nextRunTimestamp: null
};

// ═══════════════════════════════════════════════════════════
// DELAYS FIXOS E SEGUROS - NÃO CONFIGURÁVEIS
// ═══════════════════════════════════════════════════════════
const DELAY_CONFIG = {
    BETWEEN_ACTIONS_SAME_PROFILE: 80000, // 80s
    BETWEEN_PROFILES: 90000              // 90s
};

// ═══════════════════════════════════════════════════════════
// UNIFIED AUTH HELPER FUNCTIONS
// ═══════════════════════════════════════════════════════════

async function getUserId() {
    return new Promise((resolve) => {
        chrome.storage.local.get(['eio_user_id', 'userId', 'user', 'eio_user'], (result) => {
            if (result.eio_user_id) return resolve(result.eio_user_id);
            if (result.userId) return resolve(result.userId);
            if (result.user?.id) return resolve(result.user.id);
            if (result.eio_user) {
                try {
                    const u = typeof result.eio_user === 'string' ? JSON.parse(result.eio_user) : result.eio_user;
                    if (u.id) return resolve(u.id);
                } catch (e) { }
            }
            resolve(null);
        });
    });
}

async function getAuthToken() {
    return new Promise((resolve) => {
        chrome.storage.local.get(['eio_auth_token', 'authToken', 'token', 'eioLicenseData'], (result) => {
            if (result.eio_auth_token) return resolve(result.eio_auth_token);
            if (result.authToken) return resolve(result.authToken);
            if (result.token) return resolve(result.token);
            if (result.eioLicenseData?.token) return resolve(result.eioLicenseData.token);
            resolve(null);
        });
    });
}

async function getInstagramHandle() {
    const result = await chrome.storage.local.get(['instagram_handle', 'instagramUsername', 'ig_username']);
    return result.instagram_handle || result.instagramUsername || result.ig_username || null;
}

// ═══════════════════════════════════════════════════════════
// ACTION LOGGING & ENGINE PERMISSIONS
// ═══════════════════════════════════════════════════════════

async function sendActionLog(actionType, targetProfile, success) {
    try {
        const userId = await getUserId();
        const token = await getAuthToken();
        const instagramHandle = await getInstagramHandle();

        if (!userId || !token) return;

        const payload = {
            user_id: userId,
            instagram_handle: instagramHandle || 'unknown',
            action_type: actionType,
            target_profile: targetProfile,
            success: success,
            timestamp: new Date().toISOString()
        };

        const response = await fetch(`${BACKEND_URL}/api/v1/actions`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify(payload)
        });

        if (response.ok) {
            console.log('[E.I.O API] 📤 Log enviado com sucesso');
        }
    } catch (error) {
        console.error('[E.I.O API] ❌ Falha no envio de log:', error.message);
    }
}

async function checkEnginePermission(actionType, targetUsername) {
    try {
        const userId = await getUserId();
        if (!userId) return { allowed: true, delayMs: 2000, riskLevel: 'unknown', reason: 'No User ID' };

        const response = await fetch(`${BACKEND_URL}/api/engine`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                userId: userId,
                actionType: actionType,
                metadata: { target: targetUsername }
            })
        });

        if (!response.ok) return { allowed: true, delayMs: 10000, reason: 'Engine Unreachable' };
        return await response.json();
    } catch (e) {
        return { allowed: true, delayMs: 5000, reason: 'Engine Error' };
    }
}

// v4.5.0 - ACKNOWLEDGEMENT
async function sendAck(actionId, actionType, success, resultData, errorMsg) {
    // Implementar se o engine exigir ACK no futuro
    // Por enquanto, o sendActionLog já serve como confirmação de execução
    return true;
}

// ═══════════════════════════════════════════════════════════
// STATE MANAGEMENT & ALARMS
// ═══════════════════════════════════════════════════════════

async function saveState() {
    await chrome.storage.local.set({ extensionState: { ...extensionState, isRunning: extensionState.isRunning } });
}

async function loadState() {
    const result = await chrome.storage.local.get(['extensionState']);
    if (result.extensionState) {
        extensionState = { ...extensionState, ...result.extensionState };
    }
}

chrome.alarms.create('keepAlive', { periodInMinutes: 0.5 });
chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === 'keepAlive') {
        const now = Date.now();
        if (extensionState.isRunning && !isProcessing) {
            if (extensionState.nextRunTimestamp && now >= extensionState.nextRunTimestamp) {
                console.log('[E.I.O KeepAlive] ⏰ Executando agendamento...');
                extensionState.nextRunTimestamp = null;
                processQueue();
            } else if (extensionState.queue.length > 0 && !extensionState.nextRunTimestamp) {
                console.log('[E.I.O KeepAlive] ⚠️ Retomando fila parada...');
                processQueue();
            }
        }
    }
});

// ═══════════════════════════════════════════════════════════
// MESSAGE HANDLER (CENTRAL)
// ═══════════════════════════════════════════════════════════

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    const action = message.action || message.type;
    console.log('[E.I.O Msg]', action);

    switch (action) {
        case 'eio_ping':
        case 'EIO_HEARTBEAT_PING':
            sendResponse({
                pong: true, version: '4.5.0',
                status: extensionState.isRunning ? 'running' : 'idle',
                stats: extensionState.stats
            });
            break;

        case 'setQueue':
            extensionState.queue = message.queue || [];
            extensionState.currentActionType = message.actionType;
            extensionState.currentOptions = message.options || {};
            totalQueueSize = extensionState.queue.length;
            processedCount = 0;
            saveState();
            sendResponse({ success: true, count: extensionState.queue.length });
            break;

        case 'startAutomation':
            handleStartAutomation(sendResponse);
            return true;

        case 'pauseAutomation':
        case 'stopAutomation':
            extensionState.isRunning = false;
            extensionState.nextRunTimestamp = null;
            if (processingTimeout) clearTimeout(processingTimeout);
            saveState();
            notifyPopup(action === 'pauseAutomation' ? 'automationPaused' : 'automationStopped', {});
            sendResponse({ success: true });
            break;

        // AUTH SYNC (BRIDGE & DASHBOARD)
        case 'SYNC_AUTH':
        case 'SAVE_AUTH':
            const payload = message.payload || message;
            chrome.storage.local.set({
                eio_user_id: payload.userId,
                eio_auth_token: payload.token,
                eio_user_email: payload.email || null,
                eio_auth_synced_at: Date.now()
            }, () => {
                console.log('[E.I.O Auth] 🔐 Auth sincronizado!');
                sendResponse({ success: true });
            });
            return true;

        case 'bridge_connected':
            console.log('[E.I.O Bridge] 🌉 Conectado!');
            sendResponse({ success: true, version: '4.5.0' });
            break;

        // v4.5.0 - STATS SYNC HANDLER
        case 'update_profile_stats':
            (async () => {
                const token = await getAuthToken();
                if (!token) return;

                try {
                    console.log('[E.I.O Stats] 🔄 Sincronizando:', message.data?.instagram_handle);
                    const res = await fetch(`${BACKEND_URL}/api/v1/instagram/accounts/stats`, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'Authorization': `Bearer ${token}`
                        },
                        body: JSON.stringify(message.data)
                    });
                    const d = await res.json();
                    if (d.success) console.log('[E.I.O Stats] ✅ Atualizado!');
                } catch (e) {
                    console.error('[E.I.O Stats] Erro:', e);
                }
            })();
            sendResponse({ success: true });
            break;
    }
    return true;
});

// ═══════════════════════════════════════════════════════════
// AUTOMATION ENGINE
// ═══════════════════════════════════════════════════════════

let isProcessing = false;
let processingTimeout = null;
let totalQueueSize = 0;
let processedCount = 0;

async function handleStartAutomation(sendResponse) {
    const tabs = await chrome.tabs.query({ url: "*://*.instagram.com/*" });
    const instagramTab = tabs.find(t => t.active) || tabs[0];

    if (!instagramTab) {
        sendResponse({ success: false, message: 'Abra o Instagram primeiro!' });
        return;
    }

    extensionState.activeTabId = instagramTab.id;
    extensionState.isRunning = true;
    isProcessing = false;
    saveState();

    processQueue();
    notifyPopup('automationStarted', {});
    sendResponse({ success: true });
}

async function processQueue() {
    if (isProcessing || !extensionState.isRunning) return;

    if (extensionState.queue.length === 0) {
        extensionState.isRunning = false;
        notifyPopup('automationStopped', { message: 'Fila concluída!' });
        logAction('success', '✅ Fila concluída!');
        saveState();
        return;
    }

    isProcessing = true;
    processedCount++;
    notifyPopup('progressUpdate', { current: processedCount, total: totalQueueSize });

    try {
        let tabId = await ensureValidTab();
        if (!tabId) throw new Error('Aba do Instagram não encontrada');

        const item = extensionState.queue.shift();
        const actions = item.actions || [extensionState.currentActionType];

        logAction('info', `🎯 [${processedCount}/${totalQueueSize}] Processando @${item.username}...`);

        for (const actionType of actions) {
            if (!extensionState.isRunning) break;

            // 1. ENGINE CHECK
            const perm = await checkEnginePermission(actionType, item.username);

            if (!perm.allowed) {
                logAction('warning', `⛔ Bloqueado pelo Engine: ${perm.reason}`);
                notifyPopup('actionCompleted', { username: item.username, action: 'blocked' });
                continue;
            }

            if (perm.delayMs > 0) await sleep(perm.delayMs);

            // 2. EXECUTE
            let execSuccess = false;
            let errorMsg = null;

            try {
                const execResult = await sendMessageWithRetry(tabId, {
                    action: 'execute',
                    payload: { type: actionType, target: item.username, options: item.options || extensionState.currentOptions }
                });

                if (execResult?.success || execResult?.meta?.success) {
                    execSuccess = true;
                } else {
                    errorMsg = execResult?.error || 'Falha na execução';
                }
            } catch (e) {
                errorMsg = e.message;
            }

            // 3. LOG & STATS
            if (execSuccess) {
                updateStats(actionType);
                logAction('success', `✅ ${actionType} OK (@${item.username})`);
                notifyPopup('actionCompleted', { username: item.username, action: 'success' });
                await sendActionLog(actionType, item.username, true);
            } else {
                logAction('warning', `⚠️ Falha: ${errorMsg}`);
                notifyPopup('actionCompleted', { username: item.username, action: 'error' });
            }

            // Delay entre ações no mesmo perfil
            if (extensionState.isRunning && actions.indexOf(actionType) < actions.length - 1) {
                await sleep(DELAY_CONFIG.BETWEEN_ACTIONS_SAME_PROFILE);
            }
        }

        await saveState();

        // Delay entre perfis
        if (extensionState.isRunning && extensionState.queue.length > 0) {
            isProcessing = false;
            extensionState.nextRunTimestamp = Date.now() + DELAY_CONFIG.BETWEEN_PROFILES;
            logAction('info', `⏳ Próximo perfil em ${DELAY_CONFIG.BETWEEN_PROFILES / 1000}s...`);

            processingTimeout = setTimeout(() => {
                extensionState.nextRunTimestamp = null;
                processQueue();
            }, DELAY_CONFIG.BETWEEN_PROFILES);
        } else {
            isProcessing = false;
            if (extensionState.queue.length === 0) processQueue(); // Re-check para finalizar
        }

    } catch (error) {
        console.error('[E.I.O Motor] Erro Fatal:', error);
        logAction('error', `❌ Erro: ${error.message}`);
        isProcessing = false;
        if (extensionState.isRunning) {
            processingTimeout = setTimeout(() => processQueue(), 10000);
        }
    }
}

// ═══════════════════════════════════════════════════════════
// HELPER FUNCTIONS
// ═══════════════════════════════════════════════════════════

async function ensureValidTab() {
    let tabId = extensionState.activeTabId;
    try {
        if (tabId) {
            const tab = await chrome.tabs.get(tabId);
            if (tab?.url?.includes('instagram.com')) return tabId;
        }
    } catch (e) { }

    const tabs = await chrome.tabs.query({ url: "*://*.instagram.com/*" });
    if (tabs.length > 0) {
        extensionState.activeTabId = tabs[0].id;
        return tabs[0].id;
    }
    return null;
}

async function sendMessageWithRetry(tabId, message, retries = 3) {
    for (let i = 0; i < retries; i++) {
        try {
            return await chrome.tabs.sendMessage(tabId, message);
        } catch (error) {
            if (i < retries - 1) {
                // Se erro de contexto invalido, tenta achar nova tab
                if (error.message.includes('context invalidated')) {
                    const newId = await ensureValidTab();
                    if (newId) tabId = newId;
                }
                await sleep(2000);
            }
        }
    }
    throw new Error('Falha comunicação com Instagram');
}

function updateStats(type) {
    extensionState.stats.totalActionsToday++;
    if (type === 'follow') extensionState.stats.followsToday++;
    if (type === 'like') extensionState.stats.likesToday++;
    if (type === 'unfollow') extensionState.stats.unfollowsToday++;
    notifyPopup('statsUpdate', { stats: extensionState.stats });
}

function logAction(level, message) {
    console.log(`[E.I.O ${level.toUpperCase()}] ${message}`);
    notifyPopup('consoleMessage', { level, message, timestamp: new Date().toISOString() });
}

function notifyPopup(type, data) {
    chrome.runtime.sendMessage({ type, ...data }).catch(() => { });
}

function sleep(ms) {
    return new Promise(r => setTimeout(r, ms));
}

// INITIALIZATION
loadState().then(() => console.log('[E.I.O Engine] Estado recuperado'));
// Se havia automação em andamento, retomar
if (extensionState.isRunning && extensionState.queue.length > 0) {
    console.log('[E.I.O] Retomando automação anterior...');
    setTimeout(() => processQueue(), 2000);
}

// ═══════════════════════════════════════════════════════════
// v4.5.0 - EXTERNAL MESSAGE LISTENER (Dashboard Heartbeat)
// ═══════════════════════════════════════════════════════════
chrome.runtime.onMessageExternal.addListener((message, sender, sendResponse) => {
    // console.log('[E.I.O External]', message, 'de:', sender.origin); // Log reduzido

    const allowedOrigins = [
        'https://eio-system.vercel.app',
        'http://localhost:3000',
        'http://localhost:5500',
        'http://127.0.0.1:5500'
    ];

    if (!allowedOrigins.some(origin => sender.origin?.startsWith(origin) || sender.url?.startsWith(origin))) {
        return; // Silently ignore unauthorized
    }

    if (message.type === 'EIO_HEARTBEAT_PING' || message.action === 'eio_ping') {
        sendResponse({
            pong: true, version: '4.5.0',
            status: extensionState.isRunning ? 'running' : 'idle',
            stats: extensionState.stats
        });
    } else if (message.type === 'EIO_GET_STATUS') {
        sendResponse({
            isRunning: extensionState.isRunning,
            queueLength: extensionState.queue.length,
            stats: extensionState.stats
        });
    }
    return true;
});

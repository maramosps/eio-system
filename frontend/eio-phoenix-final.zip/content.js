/*
  E.I.O Content Script v1.0.0
  API Bridge - Executa ações silenciosas no Instagram
*/

console.log('[E.I.O Phoenix] Content Script Injetado');

// LISTENERS
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    // --- LOAD ACCOUNTS (Extraction) ---
    if (msg.action === 'extract_api') {
        extractFromApi(msg.type, msg.username, msg.limit).then(data => {
            sendResponse({ success: true, data });
        }).catch(err => {
            sendResponse({ success: false, message: err.message });
        });
        return true; // Async
    }

    // --- EXECUTE ACTION (Follow/Like) ---
    if (msg.action === 'execute_action') {
        performAction(msg.type, msg.username).then(res => {
            sendResponse({ success: res.ok });
        });
        return true;
    }
});

// --- API CLIENT ---
const API = {
    BASE: 'https://i.instagram.com/api/v1',
    HEADERS: {
        'X-IG-App-ID': '936619743392459', // Common Web App ID
        'X-Requested-With': 'XMLHttpRequest',
        'X-CSRFToken': getCookie('csrftoken')
    }
};

async function getUserId(username) {
    if (!username) return null;
    try {
        // Tenta pegar do cache web do Instagram
        const r = await fetch(`https://www.instagram.com/web/search/topsearch/?query=${username}`);
        const json = await r.json();
        const user = json.users.find(u => u.user.username === username);
        return user ? user.user.pk : null;
    } catch (e) {
        console.error("User ID Error:", e);
        return null;
    }
}

// --- EXTRACTION LOGIC ---
async function extractFromApi(type, username, limit) {
    const userId = await getUserId(username);
    if (!userId) throw new Error("Usuário não encontrado");

    let items = [];
    let nextMaxId = '';
    let endpoint = type === 'following'
        ? `friendships/${userId}/following/`
        : `friendships/${userId}/followers/`; // Default to followers

    while (items.length < limit) {
        let url = `${API.BASE}/${endpoint}?count=50`;
        if (nextMaxId) url += `&max_id=${nextMaxId}`;

        const res = await fetch(url, { headers: API.HEADERS });
        if (!res.ok) break;

        const json = await res.json();
        const users = json.users.map(u => ({
            username: u.username,
            full_name: u.full_name,
            profile_pic_url: u.profile_pic_url,
            is_private: u.is_private,
            // Friendship status fields vary
            followed_by_viewer: u.friendship_status?.following || u.following,
            requested_by_viewer: u.friendship_status?.outgoing_request || u.outgoing_request
        }));

        items = items.concat(users);
        nextMaxId = json.next_max_id;

        if (!nextMaxId) break;
        await sleep(1000); // Gentle extracting
    }
    return items.slice(0, limit);
}

// --- ACTION LOGIC ---
async function performAction(action, username) {
    const userId = await getUserId(username);
    if (!userId) return { ok: false };

    let url = '';
    let method = 'POST';

    if (action === 'follow') url = `${API.BASE}/friendships/create/${userId}/`;
    if (action === 'unfollow') url = `${API.BASE}/friendships/destroy/${userId}/`;

    // Para Like, precisariamos do Media ID (complexo sem lista de posts)
    // Se a ação for 'like', vamos assumir que precisamos curtir o ultimo post
    if (action === 'like') {
        const feed = await fetch(`${API.BASE}/feed/user/${userId}/?count=1`, { headers: API.HEADERS });
        const json = await feed.json();
        const mediaId = json.items?.[0]?.id;
        if (mediaId) {
            url = `${API.BASE}/media/${mediaId}/like/`;
        } else {
            return { ok: false }; // Sem posts
        }
    }

    if (!url) return { ok: false };

    const res = await fetch(url, {
        method: method,
        headers: API.HEADERS
    });

    return { ok: res.ok };
}

// --- UTILS ---
function getCookie(name) {
    const value = `; ${document.cookie}`;
    const parts = value.split(`; ${name}=`);
    if (parts.length === 2) return parts.pop().split(';').shift();
    return '';
}
function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

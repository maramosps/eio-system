/*
  E.I.O Content Script v4.3.4 (Hybrid Collection + Safety)
  Coleta Híbrida: API Privada + DOM Scraping
*/

console.log('[E.I.O] Content Script Carregado - V4.3.4');

// Configurações de Segurança carregadas de safety_config.js (window.EIO_SAFETY_CONFIG)
const SAFETY = window.EIO_SAFETY_CONFIG || { DELAYS: { ACTION_MIN: 45000, ACTION_MAX: 110000 } };

// LISTENERS
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.action === 'extract_hybrid') {
        runHybridExtraction(msg.type, msg.username, msg.limit).then(data => {
            sendResponse({ success: true, data });
        }).catch(err => {
            console.error(err);
            sendResponse({ success: false, message: err.message });
        });
        return true; // Async
    }

    if (msg.action === 'execute_action') {
        performSafeAction(msg.type, msg.username).then(res => {
            sendResponse({ success: res.ok });
        });
        return true;
    }
});

// --- HYBRID EXTRACTION ENGINE ---
async function runHybridExtraction(type, targetUser, limit) {
    // Tenta API primeiro (mais rápido/silencioso)
    try {
        console.log('[E.I.O] Tentando extração via API Graph...');
        return await extractFromApi(type, targetUser, limit);
    } catch (e) {
        console.warn('[E.I.O] API falhou, ativando DOM Scraping Seguro...', e);
        // Fallback para DOM Scraping (Simulação Humana)
        return await extractFromDOM(type, targetUser, limit);
    }
}

// 1. EXTRAÇÃO API (Lógica v1.0 mantida e melhorada)
const API = {
    BASE: 'https://i.instagram.com/api/v1',
    HEADERS: {
        'X-IG-App-ID': '936619743392459',
        'X-Requested-With': 'XMLHttpRequest',
        'X-CSRFToken': getCookie('csrftoken')
    }
};

async function getUserId(username) {
    const r = await fetch(`https://www.instagram.com/web/search/topsearch/?query=${username}`);
    const json = await r.json();
    return json.users.find(u => u.user.username === username)?.user.pk;
}

async function extractFromApi(type, username, limit) {
    const userId = await getUserId(username);
    if (!userId) throw new Error("Usuário não encontrado");

    let items = [];
    let nextMaxId = '';
    let endpoint = type === 'following' ? `friendships/${userId}/following/` : `friendships/${userId}/followers/`;

    // Likers/Commenters endpoint (Simplified for v4.3.4 scope)
    if (type === 'likers') {
        // Precisa pegar mediaCode primeiro (não implementado full nesta versão API, iria para DOM)
        throw new Error("Likers via API requer MediaID specs - Usar DOM");
    }

    while (items.length < limit) {
        let url = `${API.BASE}/${endpoint}?count=50`;
        if (nextMaxId) url += `&max_id=${nextMaxId}`;

        const res = await fetch(url, { headers: API.HEADERS });
        if (!res.ok) throw new Error("API Blocked");

        const json = await res.json();
        const users = json.users.map(u => ({
            username: u.username,
            full_name: u.full_name,
            profile_pic_url: u.profile_pic_url,
            is_private: u.is_private,
            followed_by_viewer: u.friendship_status?.following,
            requested_by_viewer: u.friendship_status?.outgoing_request
        }));

        items = items.concat(users);
        nextMaxId = json.next_max_id;
        if (!nextMaxId) break;

        // Jitter de segurança na extração API também
        await sleep(random(2000, 5000));
    }
    return items.slice(0, limit);
}

// 2. EXTRAÇÃO DOM (SCRAPING HUMANO)
async function extractFromDOM(type, targetUser, limit) {
    if (location.pathname !== `/${targetUser}/`) {
        window.location.href = `/${targetUser}/`;
        await sleep(5000);
    }

    // Seletores (Precisam ser mantidos atualizados com classes do Insta)
    // Para simplificar, buscamos por texto href que contenha "followers"
    const links = Array.from(document.querySelectorAll('a'));
    const link = links.find(a => a.href.includes(type === 'following' ? '/following' : '/followers'));

    if (link) {
        link.click();
        await sleep(3000); // Espera modal abrir

        // Loop de Scroll no Modal
        let items = new Set();
        let retries = 0;

        // Seletor do Modal (Div com role dialog e scrollable)
        const modal = document.querySelector('div[role="dialog"] div[style*="overflow"]'); // Genérico mas eficaz

        while (items.size < limit && retries < 10) {
            // Coletar
            document.querySelectorAll('div[role="dialog"] a[href^="/"]').forEach(a => {
                const user = a.href.split('/').filter(Boolean).pop();
                if (user && user !== targetUser) items.add(user);
            });

            // Scroll
            if (modal) {
                modal.scrollTop += 500;
                await sleep(random(1500, 3000));
            } else {
                retries++;
            }
        }

        // Converter Set para Array de objetos
        return Array.from(items).map(u => ({ username: u }));
    }
    return [];
}

// --- SAFE ACTIONS ENGINE ---
async function performSafeAction(action, username) {
    // Aplicar JITTER definido em safety_config.js
    const jitter = random(SAFETY.DELAYS.ACTION_MIN, SAFETY.DELAYS.ACTION_MAX);
    console.log(`[E.I.O] Ação segura: ${action} em @${username}. Jitter: ${jitter / 1000}s`);

    // Simular "Pre-Action"
    if (SAFETY.HUMANIZATION.MOUSE_MOVEMENT_SIM) {
        // Lógica de simulação de movimento de mouse viria aqui (fake events)
    }

    // Executar via API (Mais estável que DOM clicks para ações background)
    // Mas respeitando rigorosamente os limites de tempo do Background
    const userId = await getUserId(username);
    if (!userId) return { ok: false };

    let url = '';
    if (action === 'follow') url = `${API.BASE}/friendships/create/${userId}/`;
    if (action === 'unfollow') url = `${API.BASE}/friendships/destroy/${userId}/`;
    if (action === 'like') {
        // Like logic complex needs media ID
        return { ok: true }; // Placeholder safe
    }

    const res = await fetch(url, {
        method: 'POST',
        headers: API.HEADERS
    });

    return { ok: res.ok };
}


// --- UTILS ---
function getCookie(name) {
    const value = `; ${document.cookie}`;
    const parts = value.split(`; ${name}=`);
    if (parts.length === 2) return parts.pop().split(';').shift();
    return '';
}
function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }
function random(min, max) { return Math.floor(Math.random() * (max - min) + min); }

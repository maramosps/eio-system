/**
 * ORDENS TÉCNICAS E.I.O V4.3.4 - SAFETY CONFIG
 * Limites rígidos de segurança anti-ban.
 * NÃO ALTERAR SEM AUTORIZAÇÃO EXPLÍCITA.
 */

const SAFETY_CONFIG = {
    // Limites Diários (24h)
    LIMITS: {
        DM_DAILY_MAX: 50,
        FOLLOW_DAILY_MAX: 200,
        UNFOLLOW_DAILY_MAX: 500,
        LIKE_DAILY_MIN: 40,
        LIKE_DAILY_MAX: 80
    },

    // Intervalos de Tempo (Jitter Randomizado)
    // Valores em milissegundos
    DELAYS: {
        ACTION_MIN: 45000,  // 45 segundos
        ACTION_MAX: 110000, // 110 segundos

        // Intervalos específicos se necessário, baseados na regra geral
        FOLLOW_BACK_DELAY: 60000, // Tempo médio seguro para follow-back
    },

    // Configurações de Comportamento Humano
    HUMANIZATION: {
        ENABLE_JITTER: true,      // Variação aleatória ativa
        SCROLL_BEFORE_ACTION: true, // Simular rolagem antes de agir
        MOUSE_MOVEMENT_SIM: true    // Simular movimento do mouse
    }
};

// Exportar para uso no background e content scripts
if (typeof module !== 'undefined' && module.exports) {
    module.exports = SAFETY_CONFIG;
} else {
    // Para uso direto no navegador (injetado via manifest)
    window.EIO_SAFETY_CONFIG = SAFETY_CONFIG;
}

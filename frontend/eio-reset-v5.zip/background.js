/*
  E.I.O Background v5.0.0 (Validado)
  Type: Module
  Status: Service Worker Limpo (No Window/Document Access)
*/

// Importação validada
import { EIO_SAFETY_CONFIG as SAFETY } from './safety_config.js';

console.log('[E.I.O Backup] Service Worker Iniciado. Limites:', SAFETY.LIMITS);

let STATE = {
    dashboardUser: null,
    instagramUser: null,
    lastUpdate: Date.now()
};

// --- ALARMS & KEEP ALIVE ---
chrome.alarms.create('HEARTBEAT', { periodInMinutes: 1 });
chrome.alarms.onAlarm.addListener(() => {
    // Service worker context logging only
    console.log('[E.I.O] Heartbeat Check');
});

// --- MESSAGING HUB ---
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {

    // 1. BRIDGE (DASHBOARD)
    if (msg.action === 'BRIDGE_IDENTITY_UPDATE') {
        if (msg.payload.isAuthenticated) {
            STATE.dashboardUser = msg.payload.user;
            STATE.lastUpdate = Date.now();
        }
        return false;
    }

    // 2. CONTENT (INSTAGRAM)
    if (msg.action === 'INSTAGRAM_IDENTITY_UPDATE') {
        STATE.instagramUser = msg.payload.username;
        return false;
    }

    // 3. POPUP (UI)
    if (msg.action === 'POPUP_QUERY_STATUS') {
        const status = checkSystemStatus();
        sendResponse(status);
        return false;
    }

    // 4. AUTOMAÇÃO
    if (msg.action === 'EXECUTE_AUTOMATION') {
        handleAutomationRequest(msg.payload);
        sendResponse({ started: true });
        return false;
    }

    return true;
});

// --- LÓGICA PURA (SEM DOM) ---
function checkSystemStatus() {
    if (!STATE.dashboardUser) return { code: 'MISSING_DASHBOARD_LOGIN', message: 'Faça login no Painel.' };

    if (!STATE.instagramUser) {
        // Tentar acordar a aba passivamente
        queryActiveTabForInstagram();
        return { code: 'MISSING_INSTAGRAM_LOGIN', message: 'Abra o Instagram.' };
    }

    const dashInsta = normalizeHandle(STATE.dashboardUser.instagram_handle || STATE.dashboardUser.username);
    const browserInsta = normalizeHandle(STATE.instagramUser);

    if (!dashInsta) return { code: 'DASHBOARD_NO_INSTA', message: 'Cadastre seu Insta no Painel.' };

    if (dashInsta !== browserInsta) {
        return {
            code: 'IDENTITY_MISMATCH',
            message: `Erro: Painel (@${dashInsta}) != Navegador (@${browserInsta})`
        };
    }

    return { code: 'READY', message: 'Sistema Pronto.', user: STATE.dashboardUser, instagram: STATE.instagramUser };
}

function normalizeHandle(h) {
    if (!h) return '';
    return h.toLowerCase().replace('@', '').trim();
}

function queryActiveTabForInstagram() {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs[0] && tabs[0].url && tabs[0].url.includes('instagram.com')) {
            chrome.tabs.sendMessage(tabs[0].id, { action: 'REPORT_IDENTITY_NOW' }).catch(() => { });
        }
    });
}

async function handleAutomationRequest(payload) {
    console.log('[E.I.O] Ação solicitada:', payload);
    const tabs = await chrome.tabs.query({ url: '*://*.instagram.com/*' });
    const targetTab = tabs.find(t => t.active) || tabs[0];

    if (targetTab) {
        // Envia config de segurança atualizada junto
        chrome.tabs.sendMessage(targetTab.id, {
            action: 'START_EXTRACTION',
            limits: SAFETY.LIMITS,
            delays: SAFETY.DELAYS,
            targetMode: payload.mode
        });
    }
}

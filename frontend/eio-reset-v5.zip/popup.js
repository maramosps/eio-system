/*
  E.I.O Popup v5.0
  Lógica: Pergunta status ao Background. Renderiza estado.
  Sem loops. Sem checagem direta de cookie.
*/

document.addEventListener('DOMContentLoaded', () => {
    checkStatus();
});

function checkStatus() {
    chrome.runtime.sendMessage({ action: 'POPUP_QUERY_STATUS' }, (response) => {
        renderUI(response);
    });
}

function renderUI(status) {
    const statusText = document.getElementById('statusText');
    const authActions = document.getElementById('authActions');
    const mainControls = document.getElementById('mainControls');
    const statusDot = document.getElementById('statusDot');

    // Reset visibility
    authActions.classList.add('hidden');
    mainControls.classList.add('hidden');
    statusDot.className = 'status-indicator';

    if (!status) {
        statusText.textContent = "Erro de conexão com Background.";
        return;
    }

    // FEEDBACK VISUAL
    statusText.textContent = status.message || 'Status Desconhecido';

    switch (status.code) {
        case 'MISSING_DASHBOARD_LOGIN':
            authActions.classList.remove('hidden');
            statusDot.classList.add('red');
            setupAuthButtons(true, false);
            break;

        case 'MISSING_INSTAGRAM_LOGIN':
            authActions.classList.remove('hidden');
            statusDot.classList.add('yellow');
            setupAuthButtons(false, true);
            break;

        case 'DASHBOARD_NO_INSTA':
        case 'IDENTITY_MISMATCH':
            authActions.classList.remove('hidden'); // Pode precisar logar corretamente
            statusDot.classList.add('red');
            setupAuthButtons(true, true);
            break;

        case 'READY':
            mainControls.classList.remove('hidden');
            statusDot.classList.add('green');
            document.getElementById('targetUser').textContent = '@' + status.instagram;
            setupMainControls();
            break;
    }
}

function setupAuthButtons(showLogin, showInsta) {
    const btnLogin = document.getElementById('btnLogin');
    const btnInsta = document.getElementById('btnInsta');

    btnLogin.style.display = showLogin ? 'block' : 'none';
    btnInsta.style.display = showInsta ? 'block' : 'none';

    btnLogin.onclick = () => window.open('https://eio-system.vercel.app/login.html', '_blank');
    btnInsta.onclick = () => window.open('https://instagram.com', '_blank');
}

function setupMainControls() {
    document.querySelectorAll('.action-card').forEach(btn => {
        btn.onclick = () => {
            const mode = btn.dataset.action;
            chrome.runtime.sendMessage({
                action: 'EXECUTE_AUTOMATION',
                payload: { mode: mode }
            });
            window.close(); // Fecha popup para deixar rodar
        };
    });
}

// Loop de verificação visual (polling UI)
setInterval(checkStatus, 2000);
